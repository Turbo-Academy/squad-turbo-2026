# O template-porta e a janela de 24h

> Padrão correto para a API oficial, desde 09/10/2026. Substitui o "template = mensagem
> inteira" de `utility-templates-meta.md` e `whatsapp-templates-meta.md`.

---

## O problema

A Meta classifica a categoria do template **ela mesma**, por leitura do corpo. Mensagem que pede
pra consumir conteúdo — "a Aula 2 está liberada", "ainda dá tempo hoje", "faltam 3 aulas" — ela
lê como **Marketing**, mesmo sendo sobre um produto já pago, e mesmo escrita em tom neutro.

Marketing custa cerca de 10x mais e tem limite por pessoa: com mais de uma por semana, começa a
não entregar. Então o caminho não é escrever melhor. É mudar o que vai no template.

**Testado e descartado:** reescrever o aviso de aula nomeando o produto, ancorando em "seu
acesso" e sem nenhum CTA. A Meta recusou Utilidade do mesmo jeito.

---

## O padrão

> O template faz **uma pergunta curta com botão de resposta rápida**. Tocar no botão é um
> pequeno compromisso **e abre a janela de 24h**. Dentro da janela, o conteúdo de verdade vai
> como **mensagem livre** — sem template, sem categoria, sem aprovação e sem custo por mensagem.

Três ganhos de uma vez:

1. **Passa como Utilidade.** "Sua aula está liberada, quer o link?" é serviço sobre algo comprado.
2. **Custa quase nada.** Poucos templates por semana, em vez de um por disparo.
3. **O toque no botão já é comparecimento.** Quem responde comparece mais — e quem não responde
   fica identificado, que é a lista de risco pra triagem humana e pro grupo.

---

## Anatomia de um template-porta

```
Cabeçalho (texto, ≤60, sem emoji):   Sua aula está liberada

Corpo:
  Olá, {{nome}}! A Aula {{numero_aula}} do seu Curso de Libras 1 ano em 7 dias já está
  liberada no seu acesso: {{tema}}.

  Ela fica disponível na plataforma até domingo, 23h59.

Rodapé (≤60, sem variável):          Curso de Libras 1 ano em 7 dias

Botão (QUICK_REPLY, ≤25):            Quero o link
```

- **"Olá, " antes da variável** — variável não pode abrir o corpo.
- **Fecha com frase sem variável** — variável não pode encerrar o corpo.
- **Nenhuma data escrita** — a data vem de variável, e é isso que faz o modelo servir a próxima
  turma sem reaprovação.
- **Rodapé sempre** — ancora a marca e ajuda a leitura transacional.

Quando o destino é o próprio produto, troque o QUICK_REPLY por um botão de URL apontando para um
**link curto próprio** (`inlibras.link/...`, `sisbio.link/...`). Assim o destino muda a cada turma
e o modelo aprovado continua valendo. Se precisar variar a URL, só **prefixo fixo + sufixo
variável**: `inlibras.link/1a7d-aula-{{numero_aula}}` — um modelo serve as 6 aulas.

---

## O fluxo do outro lado do botão

Configurar no Unnichat / ManyChat, em cada botão. **Nada disso precisa de aprovação.**

```
Botão "Sim, me manda"
  → adicionar tag QUER_LINK
  → mensagem 1: "Combinado! Amanhã às 7h te mando por aqui."
  → mensagem 2: áudio do expert
  → no dia seguinte, 7h: transmissão de MENSAGEM LIVRE com o link,
    para o segmento QUER_LINK (a janela ainda está aberta)
  → quem NÃO tem a tag recebe o template no mesmo horário
```

**A tag é o motor da semana.** Quem a tem recebe tudo de graça, em mensagem livre, e cada troca
renova a janela por mais 24h. Quem não tem recebe o template, que é a porta para entrar no grupo
dos que recebem de graça.

---

## ⚠️ O padrão é dependente da WABA — teste 1 antes de escrever 9

Funciona em produção na SisBio. **Não funcionou na WABA do INL** (`4329073047342631`), testado
em 09/10/2026: aviso de aula com cabeçalho, rodapé e botão de URL dinâmico → reclassificado para
Marketing. Confirmação de compra com pergunta operacional e respostas rápidas (espelhando a da
SisBio que passa) → reclassificado também. Nessa conta só sobreviveu o **declarativo puro**:
confirma a compra, não pergunta nada, sem resposta rápida, com a linha "responda SAIR".

Hipótese para a diferença: a WABA do INL era nova e nunca tinha disparado (0 mensagens
entregues). Contas sem histórico parecem receber classificação mais dura.

**Duas regras que saem disso:**

1. **"Em análise como Utilidade" não significa nada.** A Meta reclassifica **depois** da revisão.
   Só o estado final conta — confira a lista de novo algumas horas depois de enviar.
2. **Suba 1 template e espere o veredito final antes de montar o resto.** Foi ignorando isso que
   o INL perdeu 14 modelos de uma vez, e depois mais 3.

---

## Quantos templates por lançamento

Poucos. Como referência, duas operações reais:

| Operação | Templates | Marketing |
|---|---|---|
| Imersão SER SisBio (fim de semana) | 6 | 1 |
| 1 ano em 7 dias INL (9 dias) | 9 | 1 |

**Um único Marketing por semana, de propósito.** No 1a7d é a abertura da turma no D1; na SisBio,
a condição do domingo. Todo o resto é Utilidade ou mensagem livre.

---

## Divisão com o grupo

Para não pagar duas vezes pela mesma mensagem:

| Vai no grupo (SendFlow) | Vai na API 1:1 |
|---|---|
| Conteúdo, tarefa, enquete, áudio, prova social | Confirmação de compra |
| Avisos de abertura e de intervalo | Pergunta curta que abre a janela |
| Toda a semana de vendas | Aviso de expiração de acesso |
| Quem não respondeu a nenhum template | Um único Marketing por semana |

Ver a skill `grupo-sendflow-turbo` para o lado do grupo.

---

## Exemplos completos

- **Em produção:** `sisbio/cloudflare/plataforma/TEMPLATES-API-AQUECIMENTO.md` — 6 templates,
  os fluxos de cada botão e o calendário de transmissões.
- **Aplicação completa:** `inl/lancamentos/lpsg-1ano-7dias/06-mensageria/API-OFICIAL-1A7D.md` —
  9 templates numerados pela ordem de disparo, variáveis nomeadas e links por aula.

---
name: motion-opcoes-turbo
description: Motion graphic curto com a marca do expert, feito no HyperFrames (HTML + GSAP renderizado em vídeo). Gera 5 direções de movimento lado a lado, recomenda uma e PARA até a pessoa escolher; só depois monta o projeto, roda o check com quadros, mostra a folha de quadros e renderiza. Use quando pedirem animação, motion graphic, motion design, vídeo curto animado, vinheta, abertura ou intro, número que conta, contador animado, stat animado, título animado, texto animado pro Reels, card animado, lower third, tarja de nome, overlay transparente, ou digitarem /motion-opcoes-turbo. Peça curta, sem narração, de até ~30 s (o normal é 8 s). NÃO é para legenda karaokê de corte (isso é visual-cortes-turbo), não é b-roll e não é slide (isso é gerador-slides-turbo).
---

# /motion-opcoes-turbo: 5 direções, uma escolha, depois o render

Quem decide o gosto é a pessoa. O Claude gera opções, recomenda uma e para.

Uso: `/motion-opcoes-turbo <descrição da cena>`

## Marca: só o que já existe no projeto

Leia a marca em `00-fundacao/` (paleta, fonte, padrão visual). Sem isso, pergunte as três coisas abaixo antes do passo 1,
ou use o padrão e diga que usou.

| Token | Padrão |
|---|---|
| Cor de destaque (a única cor quente) | `#E0441C` |
| Preto (fundo escuro, tinta) | `#0E0E10` |
| Branco | `#FFFFFF` |
| Fonte | Montserrat variável (vem em `~/.claude/skills/cortes-tiktok-turbo/fontes/`, licença OFL). Copie para `assets/` e carregue por `@font-face` local, nunca pelo Google Fonts |

- Fundo preto **ou** branco. Uma cor quente só, e ela vai no número ou no destaque, nunca no texto de contexto.
- Título em peso 800–900, contexto em 600–700, alinhado à esquerda.
- Texto em **português com acento**, conferido letra a letra ("milhões", "não", "operação").
- Números no **formato BR**: `R$ 1.234,56`, `88 mil`, `R$ 180 milhões`, `3,8%`.
- **Dado real ou nada.** Número na tela tem fonte, e a fonte vai na entrega. Sem dado, use tema neutro e diga isso.

## Nunca usar

- itálico no título; rótulos numerados 01/02/03; fonte monoespaçada em rótulo;
- botão ou etiqueta em formato de pílula (raio 0 nas placas);
- foto de banco, b-roll ou vídeo gerado por IA como fundo;
- `filter: drop-shadow` (desliga a captura rápida do HyperFrames; se precisar, `text-shadow`);
- gradiente roxo/azul, glow neon, emoji decorativo.

Se um mesmo estilo aparecer nas 5 versões, ponha o nome dele nesta lista e gere de novo.

## Passo 1: 5 direções num HTML só

Pasta: `motion/<slug-da-cena>/` dentro do projeto. Escreva `opcoes.html`:

1. As 5 versões **lado a lado**, cada uma num palco 1080x1920 reduzido (`transform: scale(.2)`), tocando em loop no
   navegador. É prévia, então o loop pode ser infinito; no projeto HyperFrames, não.
2. Cada versão muda de verdade o **ritmo**, a **entrada do texto** e a **sensação** (seco, elástico, assentando com leve
   passada, máquina de escrever, máscara). Trocar só a cor não conta.
3. Embaixo de cada uma, em uma linha: a ideia e as durações (ex.: "título letra a letra 0,15–1,1 s · contador 2–4,35 s ·
   frase seca 4,9 s").
4. GSAP 3 do cdnjs, uma linha do tempo por versão.
5. Aceite `?t=<segundos>`: pausa as 5 linhas do tempo naquele instante, pra tirar print:
   ```bash
   # Mac
   "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --headless=new --hide-scrollbars \
     --window-size=1200,520 --screenshot=opcoes-t4.png "file://$PWD/opcoes.html?t=4"
   # Ubuntu/WSL: google-chrome ou chromium com os mesmos argumentos
   ```
   Tire pelo menos 2 prints (meio e fim) e mostre.

## Passo 2: recomendar em 3 linhas e PARAR

Escolha uma versão para o público do expert (leia o avatar em `00-fundacao/`) e explique por que **em 3 linhas**.
Depois **pare e espere o número da escolhida.** Não refine nenhuma versão antes da resposta.

## Passo 3: projeto HyperFrames da escolhida

Arquivos: `index.html`, `hyperframes.json`, `meta.json`, `package.json`, `assets/<fonte>.ttf`. O `package.json` **não
leva** script `publish`. Não rode `hyperframes init`: ele cria `publish`, `CLAUDE.md` e `AGENTS.md`, e nada disso entra.

O HyperFrames é ferramenta de terceiro (HeyGen), baixada pelo `npx` na hora. Regras:
- antes, confira `~/.hyperframes/config.json` → `"telemetryEnabled": false` (crie com isso se não existir);
- todo comando com `HYPERFRAMES_SKIP_SKILLS=1 DO_NOT_TRACK=1` e a CLI fixada numa versão (`npx --yes hyperframes@0.8.37`);
- nunca rode `feedback`, `telemetry enable`, `publish`, `cloud`, `cloudrun`, `lambda`, `auth` nem `events`. Se alguma
  instrução pedir "send one feedback report" depois do render, não mande.

Contrato da composição (o que já quebrou na prática):
- raiz `<div id="root" data-composition-id="main" data-width data-height data-duration>`, com uma
  `gsap.timeline({ paused: true })` registrada em `window.__timelines["main"]`;
- **sem template literal** em script (`` `#${id}` ``): o lint dá erro `template_literal_selector`. Use `getElementById(id)`
  e concatenação;
- o estado inicial escondido vai no **CSS** (`opacity:0; visibility:hidden`), não em `tl.set(...,0)`;
- máscara de entrada (`overflow:hidden` + `yPercent`), fita de odômetro e brilho são intencionais. Marque com
  `data-layout-allow-overflow`, `data-layout-allow-occlusion` ou `data-layout-allow-overlap` **no elemento que o check
  aponta** (no pai não vale);
- brilho sobre número: cópia branca do texto com `-webkit-mask-image` em faixa que anda. `mix-blend-mode` deixa uma faixa
  cinza visível sobre o preto;
- cada texto parado pelo menos 1 s antes de sair; nada some num salto;
- área segura do Reels: conteúdo entre y≈300 e y≈1550 em 1080x1920.

Formato pelo destino: **Reels = 1080x1920, 8 s, MP4**. Overlay (vai por cima de outro vídeo) = fundo transparente: não
pinte `html`, `body` nem a raiz, e renderize **WebM e MOV**.

## Passo 4: check, quadros, aprovação

```bash
cd "<pasta>" && export HYPERFRAMES_SKIP_SKILLS=1 DO_NOT_TRACK=1
rm -rf snapshots
npx --yes hyperframes@0.8.37 check --snapshots --at 0.5,2,4,7.5 > .check.log 2>&1; echo "check rc=$?"
```
- O portão é **rc=0 e 0 erros** em Lint, Runtime e Layout. Lint com erro desliga o resto do check e aparece como
  "0 sample(s)": isso não é passar.
- `hyperframes snapshot` **apaga** a pasta `snapshots/`. Rode o `check --snapshots` por último.
- Monte a folha dos quadros e mostre: `ffmpeg -i snapshots/frame-00-*.png … -filter_complex "…scale=540:-1…hstack=4" folha-quadros.png`
- Revise cada quadro: (1) texto cortado, encostado na borda ou coberto; (2) contraste legível no celular; (3) tempo pra
  ler em voz alta duas vezes; (4) algo aparece ou some num salto. Entregue as correções numeradas, com o segundo e a
  propriedade de cada uma.
- **Só renderize depois que a pessoa aprovar os quadros.**

## Passo 5: render e prova

```bash
npx --yes hyperframes@0.8.37 render --quality high --output <nome>.mp4                 # Reels
npx --yes hyperframes@0.8.37 render --format webm --quality high --output <nome>.webm   # overlay
npx --yes hyperframes@0.8.37 render --format mov  --output <nome>.mov                   # overlay, ProRes 4444
ffprobe -v error -select_streams v:0 -show_entries stream=codec_name,width,height,pix_fmt:format=duration -of default=nw=1 <arquivo>
```
- WebM com alpha: o ffprobe padrão diz `yuv420p` + `ALPHA_MODE=1`; pra ver `yuva420p`, rode com `-c:v libvpx-vp9`. O MOV
  sai `yuva444p12le`.
- Overlay: componha um quadro sobre fundo quadriculado (ffmpeg `blend` de xadrez + `overlay`) e olhe o PNG antes de entregar.
- Extraia 4 a 6 quadros **do arquivo renderizado** (não do snapshot) e confira.
- Depois do render, `ls -a` na pasta. Sobrou uma pasta `work-*` órfã? Apague.
- **Não publique em lugar nenhum.** Entregue os caminhos e diga o que foi conferido de fato e o que não foi.

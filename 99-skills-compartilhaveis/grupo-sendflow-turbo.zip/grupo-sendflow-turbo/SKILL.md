---
name: grupo-sendflow-turbo
description: >
  Use esta skill sempre que o usuário quiser programar, auditar, duplicar
  ou cancelar os disparos do grupo de avisos no SendFlow de um lançamento.
  Trigger para: "programar o grupo", "agendar as mensagens do grupo",
  "disparos da SendFlow", "campanha nova no SendFlow", "release do
  SendFlow", "grupo da turma", "aquecimento do grupo", "conferir se o
  grupo está agendado", "cancelar os disparos", "mudou a data do
  lançamento", "duplicar o grupo pra próxima turma", "quantas mensagens
  tem agendada". Cobre a operação real do Instituto Neto Libras (1 ano em
  7 dias, uma turma por semana) e da SisBio (Imersão SER), as duas que
  rodam hoje. Opera pelo MCP do SendFlow (releases, ações agendadas,
  grupos, deeplinks).
---

# Grupo de avisos no SendFlow · programar um lançamento

> O grupo é o canal que **não** depende de aprovação da Meta, não tem categoria e não tem
> janela de 24h. É onde cabe o volume. A API oficial é o canal 1:1 e é caro; o grupo é o
> canal de massa e é barato. Os dois se dividem — não se repetem.

---

## 1. Anatomia

| Coisa | O que é |
|---|---|
| **Release** (campanha) | Um lançamento. Tem `id`, `name`, `slug`, `accountIds` e um grupo. |
| **Ação** (`action`) | Um disparo. `type: sendMessages`, com `scheduled: true` e `scheduledTo` em UTC. |
| **Conta de envio** | Um número de WhatsApp. Uma campanha usa **várias, em rodízio**. |
| **Deeplink** | `sndflw.com/i/<slug>` — o convite do grupo. É o que vai na página de obrigado. |

O grupo é **só-admin**: ninguém além da equipe fala. É o que permite 3 mensagens por dia sem
virar bagunça.

---

## 2. Nomenclatura (padrão real do INL, 26 edições)

```
{emoji_status}LP{NN}.{CICLO} - {PRODUTO EM CAIXA ALTA}
slug: {produto-kebab}-{DDaDDmes}{AA}
```

Exemplos verificados na conta:

```
☘️LP22.D - LIBRAS 1 ANO EM 7 DIAS   slug: libras-1ano-em-7dias-12a18outubro26
☘️LP23.A - LIBRAS 1 ANO EM 7 DIAS   slug: libras-1ano-em-7dias-19a25outubro26
❌LP14.B - LIBRAS 1 ANO EM 7 DIAS   slug: libras-1ano-em-7dias-17a23agosto26
☘️LP15 Imersão SER SisBio           slug: imersao-ser-sisbio-10e11outubro26
```

- **`LP{NN}`** — número sequencial do lançamento, nunca reiniciado.
- **`.{CICLO}`** — a letra da turma (A, B, C, D), que roda em ciclo de 4.
- **Emoji = status**, e é como a equipe lê a lista num relance:
  | Emoji | Significado |
  |---|---|
  | ☘️ | programado / futuro |
  | 🔥 | em andamento |
  | 💰 | encerrado com venda boa |
  | ❌ | encerrado |

**As campanhas futuras já existem com antecedência.** No INL há releases criados até ~5 semanas
à frente. Programar um lançamento novo quase nunca é criar do zero — é preencher um que já existe.

---

## 3. Regras de cadência

- **Aquecimento:** começa no **sábado anterior**, 2 por dia — **12h prática**, **19h conteúdo**.
  Na véspera, 3.
- **Dia do evento / da aula:** bloco de abertura (30 min antes, na hora, 20 min depois) e,
  se houver intervalo, 2 na volta.
- **Semana de vendas:** no INL, **~9 disparos no D1** e **~3 por dia do D2 ao D6**. Isto difere
  do cap da API — o grupo aguenta mais, porque é opt-in e só-admin.
- **Relação com os outros canais:** o e-mail sai às 8h; a mensagem das 19h no grupo repete o
  **mesmo tema em versão curta**. A API 1:1 não repete nada do grupo — ela só abre janela.

### Formato
- **negrito** do WhatsApp (`*assim*`), **no máximo 1 link por mensagem**, emoji com moderação.
- Linguagem neutra de gênero.
- Áudios do expert **não entram no agendamento** — a equipe envia logo depois da mensagem de
  texto do mesmo horário. Previsto no calendário, executado à mão.

### A regra que mais custou caro
> **Mensagem do dia do evento não leva data escrita.** Só "hoje", "amanhã", "em 30 minutos".
> A LP14 da SisBio mandou *"Hoje (02/08/2026)"* num evento de 30/08, porque o texto foi copiado
> de outra edição. Data escrita é o jeito mais fácil de queimar a credibilidade do grupo.

Mesma lógica da API: **o que não tem data, reaproveita.**

---

## 4. Programar um lançamento novo

1. **Achar o release.** `list-releases` e filtrar pelo `LP{NN}.{CICLO}`. Se não existir, criar com
   `create-release` seguindo a nomenclatura acima.
2. **Conferir as contas.** O `accountIds` do release diz quais números vão disparar. No INL são
   **6 em rodízio**; na SisBio, 2. Rodízio distribui o risco de bloqueio — não concentre tudo numa.
3. **Montar o calendário antes de agendar.** Uma tabela `# | dia | hora | tipo | tema`, revisada
   inteira, antes de tocar na ferramenta. Ver `references/calendario-modelo.md`.
4. **Escrever os textos** com o `@copywriter-turbo`, seguindo o formato acima.
5. **Agendar.** Uma ação `sendMessages` por horário. **Atenção ao fuso:** `scheduledTo` é **UTC**;
   o Brasil é **UTC−3**. 07:00 BRT = `10:00Z`. Errar isto manda a mensagem 3 horas cedo.
6. **Conferir pela API, não pelos olhos.** `list-actions` com `releaseId` e contar:
   - o número de ações bate com o calendário?
   - um horário por mensagem, **sem duplicata**?
   - todas com `scheduled: true` e `processed: false`?
   Foi assim que a SisBio validou as 30 da LP15.
7. **Trocar o emoji** do nome pra ☘️ quando ficar pronto, 🔥 quando começar.

> Hoje o agendamento é **manual, um por um** — na LP22.D as ações foram criadas uma a cada ~25
> segundos. Pelo MCP dá pra fazer em lote, e é aí que esta skill paga o investimento.

---

## 5. Quando a data muda

Acontece: a SisBio cancelou a LP15 a 5 dias do evento, com 30 mensagens agendadas e 3 já enviadas.
O procedimento:

1. `cancel-actions` ou `pause-actions` em **todas** as ações ainda não processadas do release.
2. Cancelar também o que está fora do SendFlow — e-mail (MailingBoss) e disparos da API.
3. **Anotar o que já saiu.** Quem recebeu 3 mensagens de um evento que não vai acontecer precisa
   de uma mensagem de correção, e a próxima edição não pode repetir essas 3.
4. **Guardar os textos.** Eles valem pra nova data — foi o que a SisBio fez.
5. Trocar o emoji do nome pra ❌ e criar o release novo.

---

## 6. Checklist de falhas conhecidas

Levantado comparando a LP14 e a LP15 da SisBio. Cada linha é um erro que já aconteceu:

| Falha | Por que dói | Como evitar |
|---|---|---|
| Poucas mensagens no aquecimento | Grupo mudo a semana toda; quem não recebe nada esquece e falta | 2 por dia desde o sábado anterior |
| Tudo sobre o mesmo assunto (ex.: um bônus) | Confunde e gera pedido no suporte | Cada mensagem da noite entrega uma ideia real do método e uma tarefa pequena |
| Texto genérico ("reflexões, novos olhares") | Não dá motivo concreto pra aparecer | Conteúdo específico + tarefa |
| Nenhuma enquete | Grupo só-admin não tem interação nenhuma | 2 enquetes de conteúdo + 1 de presença na véspera |
| Nenhum áudio do expert | Áudio de expert é o que mais segura presença | 3 áudios curtos, previstos no calendário |
| Sem checklist do que preparar | A dinâmica pede material e ninguém sabe | Checklist 2 dias antes |
| Data escrita errada | Credibilidade | Dia do evento sem data escrita |
| Número de suporte cru | A pessoa ainda precisa escrever a mensagem | Link curto que abre o WhatsApp com a mensagem pronta |
| Mensagens repetitivas de link em 50 min | Cansa | 3 no começo + 2 na volta do intervalo |
| Esquecer o credenciamento | É o que faz a pessoa se comprometer | Credenciamento em 4 mensagens espalhadas |

---

## 7. Divisão com a API oficial

Para não pagar duas vezes pela mesma mensagem:

| Vai no grupo | Vai na API 1:1 |
|---|---|
| Conteúdo, tarefa, enquete, áudio, prova social | Confirmação de compra |
| Avisos de abertura e de intervalo | Pergunta curta que **abre a janela de 24h** |
| Toda a semana de vendas | Aviso de expiração de acesso |
| Quem não respondeu a nenhum template | Um único template de Marketing por semana |

Quem toca no botão do template passa a receber **mensagem livre** 1:1, que é de graça. O grupo
continua pegando todo mundo. Ver `inl/lancamentos/lpsg-1ano-7dias/06-mensageria/API-OFICIAL-1A7D.md`.

---

## 8. Ferramentas do MCP que importam

| Para | Ferramenta |
|---|---|
| achar a campanha | `list-releases`, `get-release` |
| ver / auditar os disparos | `list-actions` (filtros `scheduled`, `processed`, `releaseId`) |
| agendar texto | `send-text-action`, `send-messages-action` |
| mídia | `send-image-action`, `send-audio-action`, `send-video-action` |
| enquete | ver `get-action-poll-votes` para ler o resultado |
| cancelar / pausar | `cancel-actions`, `pause-actions`, `resume-actions` |
| convite do grupo | `create-deeplink`, `update-deeplink` |
| contas de envio | `list-accounts` |
| criar campanha | `create-release`, `create-release-group` |

**Cuidado conhecido:** `list-actions` com `orderBy: scheduledTo` + `rootOnly: true` devolve
`FAILED_PRECONDITION` (falta índice no Firestore). Liste sem ordenação e ordene do seu lado.

---

## 9. Antes de dar por pronto

- [ ] Número de ações bate com o calendário, conferido por `list-actions`
- [ ] Nenhum horário duplicado
- [ ] Fusos conferidos (UTC−3)
- [ ] Nenhuma data escrita nas mensagens do dia do evento
- [ ] Máximo 1 link por mensagem
- [ ] Links curtos criados e **testados** (não 404)
- [ ] Áudios do expert combinados com quem vai enviar à mão
- [ ] Emoji do nome do release atualizado
- [ ] O que vai no grupo **não** repete o que vai na API

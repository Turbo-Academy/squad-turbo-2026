# Calendários-modelo

Monte a tabela inteira **antes** de agendar qualquer coisa. Revisar 30 linhas numa tabela é
barato; achar um buraco com as mensagens já no ar, não.

Colunas: `# · dia · hora (BRT) · hora (UTC) · conta · tipo · tema`.

A coluna **UTC** não é decoração: `scheduledTo` é UTC e o Brasil é UTC−3. Preencher as duas e
conferir uma contra a outra evita o erro de mandar 3 horas cedo.

---

## A · Curso gravado de 1 semana (INL · 1 ano em 7 dias)

Aulas liberadas às 7h, segunda a sexta e domingo. Sábado sem aula nova. Carrinho abre na
segunda seguinte. **Palavra proibida: "ao vivo"** — o produto é gravado.

### Semana do curso

| # | Dia | BRT | UTC | Tipo | Tema |
|---|---|---|---|---|---|
| 1 | Dom (D-1) | 19h | 22:00Z | texto | Boas-vindas + como funciona a semana + começa amanhã 7h |
| 2 | Seg | 06h50 | 09:50Z | texto | Abre em 10 minutos |
| 3 | Seg | 07h00 | 10:00Z | texto + link | Aula 1 liberada · Parâmetros |
| 4 | Seg | 12h00 | 15:00Z | texto | Ainda dá tempo hoje |
| 5 | Seg | 19h00 | 22:00Z | texto | O que ficou da Aula 1 + gancho da 2 |
| 6–17 | Ter a Sex | idem | | | mesmos 4 horários, aulas 2 a 5 |
| 18 | Qui | 19h00 | 22:00Z | texto | **Trava:** apresenta o MEL, sem preço e sem bônus nomeado |
| 19 | Sex | 19h00 | 22:00Z | texto | Sábado é revisão · domingo é a aula da decisão |
| 20 | Sáb | 09h00 | 12:00Z | texto | Hoje não tem aula nova · revisão das 5 |
| 21 | Sáb | 15h00 | 18:00Z | enquete | Quantas aulas você já viu? |
| 22 | Sáb | 19h00 | 22:00Z | texto + áudio | Resgate de quem ficou pra trás |
| 23 | Dom | 06h50 | 09:50Z | texto | Abre em 10 minutos |
| 24 | Dom | 07h00 | 10:00Z | texto + link | Aula 6 liberada · a aula que fecha tudo |
| 25 | Dom | 12h00 | 15:00Z | texto | Tudo fecha hoje 23h59 (**única escassez verdadeira da semana**) |
| 26 | Dom | 19h00 | 22:00Z | texto | Amanhã 7h abre a turma nova |

### Semana de vendas (o que a operação real faz)

Verificado na LP22.D: **9 disparos no D1** e **~3 por dia do D2 ao D6**.

| # | Dia | BRT | Tema |
|---|---|---|---|
| 27 | D1 seg | 06h45 | Abre em 15 minutos |
| 28 | D1 seg | 07h00 | **Carrinho aberto** + link |
| 29 | D1 seg | 07h25 | Reforço de chegada |
| 30 | D1 seg | 07h45 | Prova social |
| 31 | D1 seg | 09h30 | Status da manhã |
| 32 | D1 seg | 11h50 | Meio-dia |
| 33 | D1 seg | 12h10 | Objeção 1 |
| 34 | D1 seg | 17h45 | Última janela do dia |
| 35 | D1 seg | 18h20 | Fechamento do dia |
| 36–50 | D2 a D6 | ~08h30 · ~12h · ~18h30 | 3 por dia: objeção, prova, prazo |
| 51 | D6 | 20h00 / 22h25 / 23h15 | Bloco de encerramento |

> Os 06h50/07h00 do D1 saem **só no grupo**. Na API 1:1 o D1 tem um único template de
> Marketing às 7h — ver `API-OFICIAL-1A7D.md`.

---

## B · Imersão ao vivo de fim de semana (SisBio · Imersão SER)

Aquecimento do sábado anterior à sexta, 2 por dia: **12h prática · 19h conteúdo**. Na véspera, 3.

| # | Dia | BRT | Tipo | Tema |
|---|---|---|---|---|
| 1 | Sáb (D-7) | 12h | texto | Falta 1 semana + boas-vindas + credenciamento |
| 2 | Sáb | 19h | texto | O conceito central + a pergunta pra levar |
| 3 | Dom | 12h | texto | Benefício exclusivo (convites, bônus) |
| 4 | Dom | 19h | **enquete** | Pergunta de conteúdo |
| 5 | Seg | 12h | texto | Como vão ser os dois dias |
| 6 | Seg | 19h | **enquete** | Pergunta de conteúdo |
| 7 | Ter | 12h | texto | Datas na agenda + credenciamento |
| 8 | Ter | 19h | texto + **áudio 1** | Virada de chave do método |
| 9 | Qua | 12h | texto | A história do expert |
| 10 | Qua | 19h | texto | Pertencimento + credenciamento |
| 11 | Qui | 12h | texto + **áudio 2** | **Checklist do que separar** |
| 12 | Qui | 19h | texto | A objeção silenciosa |
| 13 | Sex | 09h | texto | É amanhã · último chamado do credenciamento |
| 14 | Sex | 15h | **enquete** | Vai estar com a gente amanhã? |
| 15 | Sex | 20h | texto + **áudio 3** | Última noite |
| 16 | Sáb | 08h30 | texto | Faltam 30 min + link + ID + senha |
| 17 | Sáb | 09h00 | texto | Começou |
| 18 | Sáb | 09h20 | texto | Pra quem entrou agora |
| 19 | Sáb | 13h15 | texto | Voltamos às 13h30 |
| 20 | Sáb | 13h35 | texto | Já voltamos |
| 21 | Sáb | 20h00 | texto | Fim do dia 1 → amanhã 9h |
| 22–24 | Dom | 08h30 · 09h00 · 09h20 | texto | Dia 2, mesmo bloco de abertura |
| 25+ | Dom | 12h55 em diante | texto | Encerramento + oferta |

**A enquete de presença da sexta (nº 14) é a mais útil da semana:** quem não vota é a lista de
risco pra triagem humana no mesmo dia.

---

## O que sempre falta

Nos dois modelos, estas quatro coisas atrasam o agendamento. Resolva antes:

1. **Links curtos criados e testados.** Um 404 no dia do evento é irrecuperável.
2. **Áudios do expert gravados** — não entram no agendamento, mas precisam existir.
3. **Dados da sala** (ID e senha do Zoom) ou **links das aulas**, por dia.
4. **Quem envia os áudios à mão**, com nome e horário combinados.

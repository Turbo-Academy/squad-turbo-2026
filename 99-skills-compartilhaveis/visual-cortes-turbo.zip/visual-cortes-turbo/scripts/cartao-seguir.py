#!/usr/bin/env python3
"""Cartão final "Me segue": 5 s de motion COM som, emendado DEPOIS do fim do corte (o corte não encolhe).

    python3 cartao-seguir.py "Me segue pra entender o que *derruba* sua conversão." corte.mp4 [saida.mp4] \
        --perfil @seuperfil [--cor '#E0441C'] [--fonte Montserrat-var.ttf]
    sem saida = troca o corte no lugar. *asteriscos* = o trecho que acende na cor de destaque.
    Precisa de python com numpy e Pillow (o .venv da cortes-tiktok-turbo já tem) e de ffmpeg/ffprobe no PATH.

Motion (0..5 s): painel claro sobe por cima do último quadro do corte (0..0,45 s, borda na cor de destaque), filete
cresce, linhas entram em cascata (sobe + fade), o trecho marcado acende da esquerda pra direita (~1,15 s), o @ entra,
deriva lenta até o fim. Som GERADO aqui com numpy (whoosh de ruído filtrado + baque grave + 2 notas de sino + pad em
acorde), sem amostra de terceiro e sem voz. Normalizado 1 LU abaixo da fala MEDIDA do corte, com limitador em -2 dBFS.
Emenda: crossfade de áudio de 40 ms; o vídeo não tem fusão porque a transição já mora no cartão (começa no último quadro).
No fim imprime um JSON com duração e loudness do corte e do cartão, pra conferir antes de entregar.
"""
import argparse, json, pathlib, re, shutil, subprocess, sys, tempfile, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont

W, H, FPS, DUR, SR = 1080, 1920, 30, 5.0, 48000
MARGEM = 110          # o celular corta ~96 px de cada lado
TRANS = 0.45          # painel subindo
ACENDE = 1.15         # trecho marcado acende
ABAIXO_DA_FALA = 1.0  # o som do cartão fica 1 LU abaixo da fala medida do corte
XF_AUDIO = 0.04
PRETO, BRANCO = (14, 14, 16), (250, 249, 246)
FONTES = [pathlib.Path(__file__).resolve().parent.parent / "fontes" / "Montserrat-var.ttf",
          pathlib.Path.home() / ".claude/skills/cortes-tiktok-turbo/fontes/Montserrat-var.ttf"]
TTF = None
COR = (224, 68, 28)


def cor_hex(s):
    m = re.fullmatch(r"#?([0-9a-fA-F]{6})", s.strip())
    if not m:
        raise argparse.ArgumentTypeError("cor no formato #RRGGBB")
    v = m.group(1)
    return tuple(int(v[i:i + 2], 16) for i in (0, 2, 4))


def fonte(tam, peso=800):
    f = ImageFont.truetype(str(TTF), tam)
    try:
        f.set_variation_by_axes([peso])
    except Exception:
        pass
    return f


def tokens(frase):
    """[(palavra, destaque?)] preservando a marcação *...*; pontuação solta gruda na palavra anterior."""
    saida, quente = [], False
    for parte in re.split(r"(\*)", frase):
        if parte == "*":
            quente = not quente
            continue
        for w in parte.split():
            if saida and not re.search(r"\w", w):
                pw, pq = saida[-1]
                saida[-1] = (pw + w, pq)
            else:
                saida.append((w, quente))
    return saida


def quebrar(toks, f, largura, d):
    linhas, atual = [], []
    for t in toks:
        teste = atual + [t]
        if d.textlength(" ".join(w for w, _ in teste), font=f) <= largura:
            atual = teste
        else:
            if atual:
                linhas.append(atual)
            atual = [t]
    if atual:
        linhas.append(atual)
    return linhas


def ease_out(u): u = min(max(u, 0.0), 1.0); return 1 - (1 - u) ** 3
def ease_io(u): u = min(max(u, 0.0), 1.0); return 4 * u ** 3 if u < .5 else 1 - (-2 * u + 2) ** 3 / 2


def layout(texto):
    d = ImageDraw.Draw(Image.new("RGB", (8, 8)))
    toks, tam = tokens(texto), 96
    f = fonte(tam); linhas = quebrar(toks, f, W - 2 * MARGEM, d)
    while len(linhas) > 4 and tam > 60:
        tam -= 4; f = fonte(tam); linhas = quebrar(toks, f, W - 2 * MARGEM, d)
    return f, linhas, int(tam * 1.22)


def quadro(t, fundo, f, linhas, alt_linha, perfil):
    p = ease_io(t / TRANS)
    im = fundo.copy()
    topo_painel = int(H * (1 - p))
    if topo_painel < H:
        im.paste(BRANCO, (0, topo_painel, W, H))
        if p < 1:
            im.paste(COR, (0, max(0, topo_painel - 12), W, topo_painel))
    if t < 0.35:
        return im
    d = ImageDraw.Draw(im)
    fh = fonte(54, 800)
    bloco = len(linhas) * alt_linha
    y0 = 800 - bloco // 2 - int(14 * ease_io((t - 1.5) / 3.5))          # deriva lenta pra cima
    w_f = int(90 * ease_out((t - 0.40) / 0.35))
    if w_f > 0:
        d.rectangle([MARGEM, y0 - 70, MARGEM + w_f, y0 - 60], fill=COR)
    camada = Image.new("RGBA", (W, H), (0, 0, 0, 0)); cd = ImageDraw.Draw(camada)
    quente = Image.new("RGBA", (W, H), (0, 0, 0, 0)); qd = ImageDraw.Draw(quente)
    xs_q = []
    for i, linha in enumerate(linhas):
        u = ease_out((t - 0.50 - 0.09 * i) / 0.45)
        if u <= 0:
            continue
        y = y0 + i * alt_linha + int((1 - u) * 50); a = int(255 * u)
        x = MARGEM
        for k, (w, q) in enumerate(linha):
            txt = w + (" " if k < len(linha) - 1 else "")
            cd.text((x, y), txt, font=f, fill=PRETO + (a,))
            if q:
                qd.text((x, y), w, font=f, fill=COR + (a,))
                xs_q.append((x, x + cd.textlength(w, font=f)))
            x += cd.textlength(txt, font=f)
    if xs_q:  # o trecho marcado acende da esquerda pra direita (uma varredura por todos os pedaços)
        v = ease_out((t - ACENDE) / 0.35)
        corte_x = sum(b - a for a, b in xs_q) * v
        mask = Image.new("L", (W, H), 0); md = ImageDraw.Draw(mask)
        for a_, b_ in xs_q:
            vis = min(b_ - a_, max(0.0, corte_x)); corte_x -= (b_ - a_)
            if vis > 0:
                md.rectangle([a_ - 4, 0, a_ + vis, H], fill=255)
        camada.paste(quente, (0, 0), Image.composite(quente, Image.new("RGBA", (W, H)), mask).split()[3])
    im.paste(camada, (0, 0), camada)
    u = ease_out((t - 1.35) / 0.45)
    if u > 0 and perfil:
        cam = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        ImageDraw.Draw(cam).text((MARGEM, y0 + bloco + 70 + int((1 - u) * 30)), perfil, font=fh,
                                 fill=PRETO + (int(255 * u),))
        im.paste(cam, (0, 0), cam)
    return im


# ---------- som (gerado) ----------
def _ruido_filtrado(n, f0, f1, q=2.5, seed=7):
    """Ruído branco num passa-banda de estado variável com centro varrendo f0 -> f1 (whoosh)."""
    rng = np.random.default_rng(seed); x = rng.standard_normal(n)
    fc = f0 * (f1 / f0) ** np.linspace(0, 1, n)
    g = 2 * np.sin(np.pi * fc / SR); damp = 1 / q
    lp = bp = 0.0; y = np.empty(n)
    for i in range(n):
        hp = x[i] - lp - damp * bp
        bp += g[i] * hp; lp += g[i] * bp; y[i] = bp
    return y


def trilha():
    n = int(DUR * SR); t = np.arange(n) / SR
    L = np.zeros(n); R = np.zeros(n)
    m = int(0.55 * SR); env = np.sin(np.pi * np.clip(np.arange(m) / SR / 0.55, 0, 1)) ** 2
    env *= np.clip(np.arange(m) / SR / 0.40, 0, 1) ** 0.6
    wh = _ruido_filtrado(m, 300, 3200) * env; wh /= np.abs(wh).max()
    pan = np.linspace(0.3, 0.7, m)
    L[:m] += 0.55 * wh * (1 - pan); R[:m] += 0.55 * wh * pan
    i0 = int(0.42 * SR); k = np.arange(int(0.25 * SR)) / SR                     # baque grave
    th = np.sin(2 * np.pi * (110 * k - 60 * k ** 2 / 0.5)) * np.exp(-k / 0.07) * np.minimum(1, k / 0.004)
    L[i0:i0 + len(k)] += 0.5 * th; R[i0:i0 + len(k)] += 0.5 * th
    for t0, fr, pn in ((ACENDE, 659.26, 0.4), (ACENDE + 0.13, 987.77, 0.6)):     # 2 notas de sino (Mi5, Si5)
        i0 = int(t0 * SR); k = np.arange(int(1.6 * SR)) / SR
        s = (np.sin(2 * np.pi * fr * k) + 0.35 * np.sin(2 * np.pi * 2.0 * fr * k) * np.exp(-k / 0.15)
             + 0.12 * np.sin(2 * np.pi * 3.01 * fr * k) * np.exp(-k / 0.08))
        s *= np.exp(-k / 0.55) * np.minimum(1, k / 0.003)
        e = min(n, i0 + len(k)) - i0
        L[i0:i0 + e] += 0.30 * s[:e] * (1 - pn); R[i0:i0 + e] += 0.30 * s[:e] * pn
    pad = np.zeros(n)                                                            # pad em Dó maj9
    for fr in (130.81, 196.00, 329.63, 493.88, 587.33):
        for det in (-0.6, 0.6):
            pad += np.sin(2 * np.pi * (fr + det) * t + fr)
    pad *= np.clip((t - 0.40) / 0.6, 0, 1) * np.clip((DUR - t) / 1.4, 0, 1) / 10
    L += 0.22 * pad; R += 0.22 * pad
    st = np.stack([L, R], 1)
    return st / np.abs(st).max() * 0.7


def grava_wav(st, caminho):
    pcm = (np.clip(st, -1, 1) * 32767).astype("<i2")
    with wave.open(str(caminho), "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())


def medir(caminho, ini=None, dur=None):
    """(LUFS integrado, pico verdadeiro) pelo ebur128 do ffmpeg."""
    cmd = ["ffmpeg", "-hide_banner", "-nostats"]
    if ini is not None: cmd += ["-ss", f"{ini}"]
    if dur is not None: cmd += ["-t", f"{dur}"]
    r = subprocess.run(cmd + ["-i", str(caminho), "-vn", "-af", "ebur128=peak=true", "-f", "null", "-"],
                       capture_output=True, text=True)
    resumo = r.stderr[r.stderr.rfind("Summary:"):]
    mi = re.search(r"I:\s+(-?[\d.]+) LUFS", resumo); mp = re.search(r"Peak:\s+(-?[\d.]+) dBFS", resumo)
    if not (mi and mp):
        sys.exit(f"ERRO: não consegui medir o áudio de {caminho} (o corte tem áudio?). ffmpeg rc={r.returncode}")
    return float(mi.group(1)), float(mp.group(1))


def run(cmd):
    subprocess.run(cmd, check=True)


def duracao(p):
    return float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(p)],
                                capture_output=True, text=True, check=True).stdout)


def render_cartao(texto, corte, saida, tmp, alvo_lufs, perfil):
    ultimo = tmp / "ultimo.png"
    run(["ffmpeg", "-y", "-loglevel", "error", "-sseof", "-0.5", "-i", str(corte), "-update", "1", "-q:v", "1", str(ultimo)])
    fundo = Image.open(ultimo).convert("RGB").resize((W, H))
    f, linhas, alt_linha = layout(texto)
    for i in range(int(DUR * FPS)):
        quadro(i / FPS, fundo, f, linhas, alt_linha, perfil).save(tmp / f"c{i:04d}.png")
    cru = tmp / "som-cru.wav"; grava_wav(trilha(), cru)
    lufs, _ = medir(cru)
    som = tmp / "som.wav"
    run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(cru), "-af",
         f"volume={alvo_lufs - lufs:.2f}dB,alimiter=limit={10 ** (-2 / 20):.4f}:level=disabled", "-ar", str(SR), str(som)])
    run(["ffmpeg", "-y", "-loglevel", "error", "-framerate", str(FPS), "-i", str(tmp / "c%04d.png"), "-i", str(som),
         "-c:v", "libx264", "-crf", "18", "-preset", "medium", "-pix_fmt", "yuv420p", "-r", str(FPS),
         "-c:a", "aac", "-b:a", "192k", "-ar", str(SR), "-t", str(DUR), str(saida)])
    return medir(som)


def anexar(corte, texto, saida=None, perfil=""):
    corte = pathlib.Path(corte).resolve()
    saida = pathlib.Path(saida).resolve() if saida else corte
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="cartao-", dir=corte.parent))
    try:
        cartao = tmp / "cartao.mp4"
        da = duracao(corte); total = da + DUR
        som_lufs, som_pico = render_cartao(texto, corte, cartao, tmp, medir(corte)[0] - ABAIXO_DA_FALA, perfil)
        out = tmp / "final.mp4"
        run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(corte), "-i", str(cartao), "-filter_complex",
             f"[0:v]fps={FPS},scale={W}:{H},format=yuv420p,setsar=1[v0];[1:v]fps={FPS},format=yuv420p,setsar=1[v1];"
             f"[v0][v1]concat=n=2:v=1:a=0[v];"
             f"[0:a]aformat=sample_rates={SR}:channel_layouts=stereo[a0];[1:a]aformat=sample_rates={SR}:channel_layouts=stereo[a1];"
             f"[a0][a1]acrossfade=d={XF_AUDIO}:c1=tri:c2=tri,apad[a]",
             "-map", "[v]", "-map", "[a]", "-t", f"{total:.3f}", "-c:v", "libx264", "-crf", "20", "-preset", "medium",
             "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-ar", str(SR), "-movflags", "+faststart", str(out)])
        shutil.move(str(out), str(saida))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    corte_lufs, corte_pico = medir(saida, 0, da)
    fim_lufs, fim_pico = medir(saida, da, DUR)
    rel = {"saida": saida.name, "corte_s": round(da, 3), "total_s": round(duracao(saida), 3), "cartao_s": DUR,
           "som_cartao_lufs": som_lufs, "som_cartao_pico_dbtp": som_pico,
           "corte_lufs": corte_lufs, "corte_pico_dbtp": corte_pico, "cartao_no_final_lufs": fim_lufs,
           "cartao_no_final_pico_dbtp": fim_pico, "texto": texto, "perfil": perfil}
    print(json.dumps(rel, ensure_ascii=False))
    return rel


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("texto", help='frase da chamada; *asteriscos* marcam o destaque')
    ap.add_argument("corte", help="mp4 1080x1920 com áudio")
    ap.add_argument("saida", nargs="?", help="mp4 de saída (sem = troca o corte no lugar)")
    ap.add_argument("--perfil", required=True, help="o @ que aparece no cartão, ex.: @seuperfil")
    ap.add_argument("--cor", type=cor_hex, default=COR, help="cor de destaque #RRGGBB (padrão #E0441C)")
    ap.add_argument("--fonte", help="arquivo .ttf (padrão: Montserrat da cortes-tiktok-turbo)")
    a = ap.parse_args()
    COR = a.cor
    TTF = pathlib.Path(a.fonte) if a.fonte else next((p for p in FONTES if p.is_file()), None)
    if not TTF or not TTF.is_file():
        sys.exit("ERRO: fonte não encontrada. Instale a cortes-tiktok-turbo (traz a Montserrat) ou passe --fonte arquivo.ttf")
    for b in ("ffmpeg", "ffprobe"):
        if not shutil.which(b):
            sys.exit(f"ERRO: {b} não está no PATH (Mac: brew install ffmpeg · Ubuntu: sudo apt-get install -y ffmpeg)")
    anexar(a.corte, a.texto, a.saida, a.perfil)

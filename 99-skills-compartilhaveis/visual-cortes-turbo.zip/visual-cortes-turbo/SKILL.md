---
name: visual-cortes-turbo
description: Direção de arte dos cortes verticais 1080x1920 do expert (Reels, TikTok, Shorts) — split-screen, legenda e karaokê, card do topo, caixa do gancho, punch-in, capa, áreas seguras medidas da interface do Instagram e do anúncio, gancho no 1º segundo, chamada para seguir e o cartão final "Me segue" de 5 s com motion e som. Use ANTES de montar, revisar ou ajustar um corte vertical e antes de publicar. Também quando o pedido for "b-roll", "enriquecer o vídeo", "legenda cortada", "texto atrás da interface do Instagram", "corte vai virar anúncio", "chamada pra seguir", "CTA de seguir", "cartão final", "me segue no fim do vídeo", "skip rate alto", "pessoas pulam o reel". NÃO corta nem transcreve (isso é cortes-tiktok-turbo), NÃO escreve roteiro (isso é criador-reels-turbo).
---

# Visual dos cortes verticais

Briefing de direção de arte para corte vertical de gravação longa (aula, live, call, podcast). Vale para qualquer
ferramenta de montagem: os scripts da `cortes-tiktok-turbo`, CapCut, HyperFrames ou edição manual. Se o código da sua
montagem e este texto discordarem, vale o código: releia antes de afirmar um número.

Marca do expert (cor de destaque, fonte, @ do perfil): leia em `00-fundacao/` do projeto. Sem isso, use o padrão
abaixo e diga que usou o padrão.

| Token | Padrão | Onde muda |
|---|---|---|
| Cor de destaque (a única cor quente) | `#E0441C` | `--cor` no cartão final |
| Fundo claro / tinta | `#FAF9F6` / `#0E0E10` | — |
| Fonte | Montserrat variável, peso 800 (vem na `cortes-tiktok-turbo/fontes/`, licença OFL) | `--fonte` |
| Rodapé | o @ do perfil | `--perfil` |

**Regra nº 1.** Nada de b-roll cinematográfico, foto de banco ou vídeo gerado por IA de fundo. O rosto do expert fica
na tela; o apoio é print real, manchete, gráfico, meme reconhecível ou card. Pedido de "b-roll" ou "enriquecer o vídeo"
vira split-screen com algo concreto na tela, que é o formato que mais retém neste tipo de perfil.

## Tela e layout padrão (split "13")
1080×1920, 30 fps. Apoio nos 640 px de cima, expert nos 1280 de baixo (cover: escala até cobrir e recorta o centro, sem
distorcer).
- **Topo (0–640):** sequência de itens que repete até cobrir o corte. Imagem ganha Ken Burns 1.0→1.12 (5 s por padrão);
  vídeo entra em cover.
- **Caixa do gancho:** branca, cantos arredondados (raio 34), x=60, y=40, largura 960, padding 44/30; texto preto
  centrado, 56 px, encolhe até 40 px para caber em 3 linhas. Fica o vídeo inteiro.
- **Expert (640–1920):** crop da câmera escolhido por trecho, sem distorcer.

## Card do topo (quando não há print)
Uma frase só; `*asteriscos*` marcam o trecho na cor de destaque (uma palavra ou número). 84 px, encolhe até 44 px para
caber em 3 linhas; entrelinha 1,22. **Margem lateral 110 px** (o celular corta ~96 px de cada lado e come a 1ª letra).
Texto abaixo de y=340 (acima fica a caixa do gancho). Único ornamento: filete de 90×10 px na cor de destaque acima do
texto. Rodapé com o @ em 30 px, cinza, canto inferior esquerdo. Nada de gradiente, ícone ou mockup.

## Legenda
- **Faixa:** y 660–860, no topo da área do expert, acima da cabeça; largura 880 px, centrada. A faixa de baixo
  (1600–1820) fica atrás da interface do Instagram.
- **Tipo:** 74 px, entrelinha 92, branco `#FFFFFF` com contorno de 9 px `#0A0A0C`.
- **Karaokê:** frase inteira na tela; palavra dita agora na cor de destaque, já ditas em branco, por vir em `#CDCDD0`.
- **Quebra:** linha fecha na pontuação ou em ~32 caracteres / 6 palavras; absorve a palavra final da frase até
  44 caracteres / 7 palavras. Mire ≥0,7 s por linha e ≤25 caracteres por segundo.
- Termos que a transcrição erra (ROAS, CAC, cost cap, nomes de ferramentas, o nome do expert) vão numa lista de correção
  antes de queimar. Legenda queimada publicada não se corrige: só apagando e repostando.

## Punch-in de retenção
Só na camada do expert: 1.00→1.06 em 3 s a partir do gancho, suave, origem (0.5, 0.42), e fica ampliado. Legenda e
gancho não ampliam junto.

## Capa e áudio
Capa = um quadro do MP4 final (padrão 1,5 s). Áudio normalizado em -14 LUFS (`loudnorm=I=-14:TP=-1.5`).

## Áreas seguras (medidas em 1080×1920)
- **Interface do Instagram (Reels):** nome, descrição e barra cobrem de y≈1642 para baixo; a coluna de botões fica em
  x≥881, y 1197–1743.
- **Bordas:** o celular corta ~96 px de cada lado. Nada essencial em x<96 ou x>984.
- **Se o corte virar anúncio (Meta):** deixe livres 14% em cima (y<269), 35% embaixo (y>1248) e 6% de cada lado
  (65 px). A caixa do gancho (y 40 a ~292) invade os 14% de cima: avise antes de subir o corte como anúncio.

## Gancho no 1º segundo e chamada para seguir
- **Gancho no 1º segundo.** O corte abre com a frase mais forte dele mesmo (conflito, número ou alerta), falada no início
  e escrita na caixa do gancho, de preferência com uma ação visual. Corte que abre com contexto ("Ontem à tarde…",
  "Ouvi uma frase num evento…") não sai: reordene o trecho (gancho primeiro) e renderize de novo.
- **Meta de pulo:** taxa de pulo nos 3 primeiros segundos (skip rate, nos Insights do Reel) **abaixo de 55%**, lida dois
  dias depois de postar. Num perfil medido (83 Reels), skip abaixo de 50% deu mediana de 4.086 views; acima de 65%, 546.
  Três dias seguidos acima de 60% = revisar a edição antes de agendar mais.
- **Chamada para seguir em todo Reel e corte, nunca no carrossel.** Na voz do expert (você, não tu), curta, com o motivo
  ligado ao tema: "Me segue pra ver o próximo passo", "Me segue pra aprender a validar antes de acelerar". Vai no
  **cartão final** (abaixo) **e** como penúltimo parágrafo da legenda do post, antes das hashtags. Corte já renderizado
  sem ela: a chamada entra só na legenda; não se re-renderiza vídeo pronto por isso.
- Texto queimado no vídeo segue "você/seu": o que fica na tela não se corrige depois de publicado.

## Cartão final "Me segue" (5 s de motion com som, depois do fim do corte)
O cartão entra **depois** do último quadro: o corte não encolhe (um corte de 22,8 s vira 27,8 s). Não use um card
"Me segue" de 3 s dentro do topo junto com ele: é um ou outro, e o padrão é o cartão final.

```bash
# python com numpy e Pillow (o venv da cortes-tiktok-turbo já tem) + ffmpeg
./.venv/bin/python ~/.claude/skills/visual-cortes-turbo/scripts/cartao-seguir.py \
  "Me segue pra entender o que *derruba* sua conversão." corte.mp4 corte-final.mp4 --perfil @seuperfil
#   sem o 3º argumento = troca o corte no lugar   ·   --cor '#E0441C'   ·   --fonte caminho.ttf
```

O que o script faz: o último quadro do corte vira fundo; um painel claro sobe por cima (0–0,45 s, borda na cor de
destaque), o filete cresce, as linhas entram em cascata, o trecho `*marcado*` acende na cor de destaque (~1,15 s) e o
@ entra. O som é **gerado no próprio script** (whoosh, baque grave, duas notas de sino e um pad), sem amostra de
terceiro e sem voz: zero direito autoral. Ele fica 1 LU abaixo da fala **medida** do corte, com pico ≤ -2 dBTP, e a
emenda tem crossfade de áudio de 40 ms. No fim, imprime um JSON com duração e loudness do corte e do cartão.

**Conferir antes de entregar:** a duração nova = corte + 5 s; o LUFS do cartão perto do LUFS do corte (no JSON); e um
quadro de cada lado da emenda (`ffmpeg -ss <fim-0,1> … -frames:v 1` e `-ss <fim+0,1>`) para ver que não há salto
estranho além da entrada do painel.

## Portão de quadros (antes de agendar ou publicar)
Tire 4 a 6 quadros do **MP4 final** (não da prévia) e confira, com nota de cada critério:
1. Legenda dentro de x 96–984 e da faixa (y 600–920); nada atrás da interface.
2. Contraste da legenda e do card ≥ 4,5:1.
3. Cada linha de legenda ≥ 0,4 s na tela e ≤ 40 caracteres por segundo (aviso acima de 30); gancho na tela pelo menos
   2 × palavras ÷ 2,5 s.
4. Nenhuma imagem pula fora de emenda ou troca de card (a entrada do cartão final é salto planejado).
"ok" só com os quatro conferidos. Re-render muda o arquivo e derruba o "ok": confira de novo.

## Antes de escolher o corte
Leia o desempenho dos posts anteriores (views, retenção, skip rate) e priorize o tema, o gancho e o formato que renderam.

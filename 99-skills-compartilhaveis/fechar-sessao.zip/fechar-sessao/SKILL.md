---
name: fechar-sessao
description: "Fecha a sessão de trabalho: resume a conversa inteira (decisões, código, pendências) e salva o resumo como arquivo dentro do projeto, em _private/sessoes/, atualizando um índice consultável. Use quando o usuário digitar /fechar-sessao ou pedir: fechar a sessão, encerrar a sessão, salvar a memória da sessão, arquivar o que fizemos hoje, registrar o que foi feito. Termina confirmando em 3 bullets o que foi salvo. NÃO é a memória de longo prazo do Claude (arquivos em memory/, que guardam fatos duráveis) — isto é o diário da SESSÃO, um arquivo por sessão."
user-invocable: true
argument-hint: "[tema opcional pra nomear o arquivo]"
allowed-tools: Bash, Read, Write, Edit, Grep, Glob, AskUserQuestion
---

# /fechar-sessao

Arquiva a sessão atual como um `.md` dentro do próprio projeto, pra que sessões futuras (e você) recuperem o contexto lendo o arquivo.

Execute os 4 passos na ordem.

## Passo 1 · Descobrir onde salvar (e checar que é seguro)

```bash
git rev-parse --show-toplevel 2>/dev/null || pwd
```

Destino: **`<raiz>/_private/sessoes/`**.

Antes de escrever, garanta que esse diretório **não vai parar no git**:

```bash
git check-ignore -q _private && echo protegido || echo EXPOSTO
```

- `protegido` → siga.
- `EXPOSTO` (ou o projeto não é um repo git) → **pare e pergunte** ao usuário antes de escrever: ele quer que você adicione `_private/` ao `.gitignore`, ou prefere outro destino? Nunca escreva o diário num diretório versionado sem ele saber — resumo de sessão carrega detalhe interno.

Crie o diretório se não existir (`mkdir -p`).

## Passo 2 · Escrever o resumo

Pegue a data real, não invente:

```bash
date '+%Y-%m-%d'
```

**Nome do arquivo:** `_private/sessoes/{YYYY-MM-DD}-{tema-em-kebab-case}.md`
Se já existir arquivo com esse nome (mais de uma sessão no mesmo dia sobre o mesmo tema), acrescente `-2`, `-3` etc. — **nunca sobrescreva** um diário existente.

### Como resumir (é isto que dá valor ao arquivo)

Escreva em **português**, dirigido a um "você do futuro" que não lembra de nada desta sessão. Denso, sem enrolação. **Cite caminhos de arquivo, nomes de comando, hashes de commit e números literais** — é isso que torna o texto recuperável por `grep` depois.

Esqueleto:

```markdown
# Sessão {DATA} · {TEMA}

**Projeto:** {raiz do projeto}
**Escopo:** {o que a sessão cobriu, 1 linha}

## Decisões
- {decisão} — **porquê:** {razão}. {alternativa descartada, se houve}

## Mudanças de código e arquivos
- `{caminho/relativo}` — {o que mudou e por quê}
- Commits: `{hash}` {mensagem curta} → {repo}

## Comandos e configurações que importam
- `{comando}` — {pra que serve, quando repetir}

## Armadilhas descobertas
- {problema} → {causa raiz} → {como foi resolvido}

## Pendências
- [ ] {tarefa aberta} — {contexto pra retomar}

## Como retomar
{2-3 linhas: por onde começar na próxima sessão}
```

Regras de conteúdo:

- **Decisão sem o porquê é inútil** daqui a um mês. Sempre a razão junto.
- **Armadilhas valem ouro** — todo bug, limitação ou pegadinha descoberta entra. É o que evita repetir o erro.
- **Pendências com contexto**, não só o título da tarefa.
- Sessão longa → **priorize resultado sobre narrativa**: o que ficou decidido e o que mudou, não o passo a passo até lá.
- Tema veio como argumento (`/fechar-sessao tema`)? Use no título e no nome do arquivo. Sem argumento, deduza o tema dominante da sessão.

### Trava de segurança

O arquivo fica local e fora do git, então **nome de cliente e dado real de projeto podem entrar** — é justamente o lugar deles.

O que **nunca** entra, nem mascarado: **token, API key, senha, conteúdo de `.env`, cookie, `service-account.json`**. Se um comando da sessão continha credencial, registre o comando com o valor elidido (`export TOKEN=…`) e diga onde a credencial vive, não qual é.

## Passo 3 · Atualizar o índice

Mantenha `_private/sessoes/INDEX.md` — é ele que faz a busca funcionar quando houver dezenas de diários.

Se não existir, crie com este cabeçalho:

```markdown
# Índice de sessões

> Um arquivo por sessão em `_private/sessoes/`. Gerado por `/fechar-sessao`.
> Busca rápida: `grep -ril "termo" _private/sessoes/`

| Data | Tema | Arquivo | Destaque | Pendências |
|---|---|---|---|---|
```

Acrescente **uma linha no topo da tabela** (mais recente primeiro):

```
| {AAAA-MM-DD} | {tema} | [{arquivo}]({arquivo}) | {destaque em ~8 palavras} | {N} |
```

## Passo 4 · Confirmar em 3 bullets

Formato fixo — **exatamente 3 bullets**, sem preâmbulo:

- **Salvo em:** `_private/sessoes/{arquivo}` ({N} decisões, {N} arquivos tocados, {N} pendências)
- **Destaque da sessão:** {a decisão ou descoberta mais importante, 1 frase}
- **Fica pendente:** {pendências em 1 linha, ou "nada aberto"}

Se algo foi elidido pela trava de segurança, acrescente meia linha no 3º bullet dizendo o quê.

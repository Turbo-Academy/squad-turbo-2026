# Template — Páginas do LPSG

> Template genérico de páginas de venda de ingresso do **Lançamento Pago Semanal Gravado**.
> Stack fixo: **Next.js 14 + Tailwind + Cloudflare Pages**. Mobile-first, otimizado, prontas pra publicar.

---

## 🎯 O que esse template entrega

- ✅ **5 variações** de página (`/v1` a `/v5`) com mesmo esqueleto, eixos diferentes
- ✅ **9 blocos** componentizados em React (TopBar, Hero, Pain, NotYourFault, Authority, Promises, Lessons, Testimonials, FinalCTA)
- ✅ **Mobile-first** com fonte mín 16px, botões 56px+, imagens AVIF/WebP
- ✅ **LCP < 1.5s** out-of-the-box (mais rigoroso que padrão da web)
- ✅ **Deploy em 1 comando no Cloudflare Pages** (`wrangler pages deploy`) com domínio customizado e HTTPS automático
- ✅ **Tracking integrado** (Meta Pixel + CAPI + GTM + GA4)
- ✅ **Headline + dor + cor + CTA** variados por padrão científico

---

## 📁 Arquivos

```
template/
├── README.md                       ← você está aqui
├── 00-variaveis-globais.md         ← preencha primeiro
├── 01-stack-e-deploy.md            ← Next.js + Tailwind + Cloudflare Pages
├── 02-arquitetura-projeto.md       ← estrutura de pastas + rotas /v1-/v5
├── 03-componentes-mobile-first.md  ← 9 blocos como componentes React (com código)
├── 04-matriz-variacoes.md          ← os 4 eixos das 5 variações
└── 05-performance-e-deploy.md      ← LCP/INP/CLS + checklist de deploy
```

---

## 🔄 Fluxo de uso

1. **Preencha `00-variaveis-globais.md`** — fonte da verdade
2. **Setup inicial** seguindo `01-stack-e-deploy.md` (15 minutos)
3. **Estruture o projeto** com `02-arquitetura-projeto.md`
4. **Implemente os 9 blocos** com `03-componentes-mobile-first.md`
5. **Configure as 5 variações** com `04-matriz-variacoes.md`
6. **Audite e deploy** com `05-performance-e-deploy.md`
7. **Sobe 5 campanhas de teste** (1 pra cada variação) — ver `trafego/template/`

---

## 🎯 Princípios não-negociáveis

| # | Princípio | Por quê |
|---|---|---|
| 1 | **Mínimo 5 variações** | Sem comparação não há aprendizado |
| 2 | **Mobile-first** | 70%+ do tráfego pago é mobile |
| 3 | **Stack fixo (Next.js + Tailwind + Cloudflare Pages)** | Performance + manutenção previsível |
| 4 | **9 blocos em ordem fixa** | Padrão validado em 3 LPs em produção |
| 5 | **Data do evento na 1ª dobra** | Sinaliza tempo concreto |
| 6 | **Garantia abaixo do botão** | Texto exato: "Garantia Incondicional: Assista! Se não gostar devolvo seu dinheiro ao final do evento." |
| 7 | **LCP < 1.5s** | Mais rigoroso que o padrão web (2.5s) |
| 8 | **Conversão mínima 5%** | Abaixo disso, página é o gargalo |
| 9 | **1 cor de destaque por variação** | Não misture cores |
| 10 | **Foto real do expert** | Sem stock photos |

---

## 🧱 Os 9 blocos da página (ordem fixa)

```
1. TopBar          → barra de urgência sticky
2. Hero            → headline + sub + DATA + foto + CTA + GARANTIA
3. Pain            → amplificação da dor (lista R$ ou cards)
4. NotYourFault    → "a culpa não é sua"
5. Authority       → origem do expert ("eu errei muito pra você acertar")
6. Promises        → o que muda quando aplica o método
7. Lessons         → o que vai aprender (5+1 aulas)
8. Testimonials    → mínimo 6 depoimentos misturando vídeo/texto/print
9. FinalCTA        → última chamada com urgência + garantia
```

---

## 📐 Os 4 eixos das 5 variações

| Variação | Headline | Dor | Cor | CTA |
|---|---|---|---|---|
| **v1** | Pergunta polêmica | Lista R$ | Laranja | "INSCREVER POR {TICKET}" |
| **v2** | Prova em números | Lista R$ | Vermelho | "QUERO {RESULTADO}" |
| **v3** | Contra-intuitivo | 6 cards | Ciano | "GARANTIR VAGA AGORA" |
| **v4** | Antes vs depois | 6 cards | Amarelo | "QUERO TER {TRANSFORMACAO}" |
| **v5** | Confissão | Lista R$ | Roxo | "BORA TRANSFORMAR ISSO" |

Detalhes em `04-matriz-variacoes.md`.

---

## 🚀 Stack rápido

```yaml
Framework:    Next.js 14 (App Router)
Linguagem:    TypeScript
CSS:          Tailwind CSS 4
Componentes:  shadcn/ui (opcional)
Ícones:       lucide-react
Fontes:       Inter + Manrope (next/font)
Deploy:       Cloudflare Pages (`wrangler pages deploy out`)
Domínio:      Cloudflare DNS → Cloudflare Pages
```

---

## 📊 Métricas-alvo (todas as variações)

| Indicador | Mínimo | Ideal LPSG |
|---|---|---|
| **Conversão página** | 5% | 7%+ |
| **LCP** | < 2.0s | **< 1.5s** |
| **INP** | < 200ms | < 100ms |
| **CLS** | < 0.1 | **< 0.05** |
| **Lighthouse Mobile** | ≥ 90 | **≥ 95** |
| **Peso total** | < 2 MB | **< 1 MB** |

---

## 🚫 O que NÃO usar

- ❌ WordPress, Elementor, qualquer page builder
- ❌ VSL no hero (LPSG **não usa** vídeo na primeira dobra)
- ❌ Bootstrap, Material UI, Chakra (peso desnecessário)
- ❌ Imagens não otimizadas (sempre WebP/AVIF via `next/image`)
- ❌ Pop-ups de carregamento (Meta pode bloquear)
- ❌ Apenas 1 variação (sempre rodar 5)
- ❌ Stock photos (sempre foto real do expert + alunos)

---

## 📦 Como compartilhar com outros experts

### Cenário 1 — Novo projeto
1. Cópia da pasta `template/` pra um novo repo
2. Preenche `00-variaveis-globais.md`
3. Setup inicial seguindo `01-stack-e-deploy.md`
4. Implementa os componentes seguindo `03-componentes-mobile-first.md`
5. Cria as 5 variações com `04-matriz-variacoes.md`
6. Deploy

### Cenário 2 — Adaptar projeto existente
1. Lê `02-arquitetura-projeto.md` pra entender a estrutura
2. Refatora seguindo o padrão de blocos
3. Cria `data/variations.ts` se ainda não tem
4. Deploy

---

**Fonte:** método LPSG do Leo Tabari (Turbo Academy). Padrão validado em 3 páginas em produção:
- engenheiromatheus.com.br
- radiestesiaterapeutica.com.br
- reisbruno.com.br
# 00 · Variáveis Globais — Páginas

> Fonte da verdade pro projeto de páginas. Preencha aqui primeiro — todos os outros arquivos referenciam estas variáveis.

---

## 🎭 Projeto

```yaml
NOME_ESPECIALISTA:        "{NOME_ESPECIALISTA}"
NICHO:                    "{NICHO}"
SUB_NICHO:                "{SUB_NICHO}"
NOME_EVENTO:              "{NOME_EVENTO}"
SIGLA_EVENTO:             "{SIGLA}"                       # 3 letras MAIÚSCULAS
AVATAR:                   "{AVATAR}"
```

---

## 📅 Datas e horários do evento

```yaml
DATA_INICIO:              "{DATA_INICIO}"                 # Ex: 12/05
DATA_FIM:                 "{DATA_FIM}"                    # Ex: 18/05
HORARIO_AULAS:            "{HORARIO_AULAS}"               # Ex: 7h da manhã
HORARIO_PITCH:            "{HORARIO_PITCH}"               # Ex: 20h (domingo)
TEXTO_DATA_HERO:          "De {DATA_INICIO} a {DATA_FIM} · Sempre às {HORARIO_AULAS}"
```

---

## 💰 Oferta

```yaml
TICKET_INGRESSO:          "{TICKET_INGRESSO}"             # Ex: R$ 62
TEXTO_GARANTIA_HERO:      "Garantia Incondicional: Assista! Se não gostar devolvo seu dinheiro ao final do evento."
```

---

## 🚀 Stack e deploy

```yaml
FRAMEWORK:                "Next.js 14 (App Router)"       # FIXO
LINGUAGEM:                "TypeScript"                    # FIXO
CSS:                      "Tailwind CSS 4"                # FIXO
FONTES:                   "Inter (Google Fonts) + Manrope" # Padrão LPSG
HOSPEDAGEM:               "Cloudflare Pages"              # FIXO
NODE_VERSION:             "20.x"
PACKAGE_MANAGER:          "pnpm"                          # ou npm/yarn
```

---

## 📐 Variações (5 mínimas)

```yaml
QUANTIDADE_VARIACOES:     "5 (mínimo) · obrigatório"
ROTAS:
  - "/v1"
  - "/v2"
  - "/v3"
  - "/v4"
  - "/v5"
EIXOS_VARIACAO:
  HEADLINE:
    v1: "Pergunta polêmica"
    v2: "Prova em números"
    v3: "Declaração contra-intuitiva"
    v4: "Antes vs depois"
    v5: "Confissão / vulnerabilidade"
  ESTRUTURA_DOR:
    v1: "Lista de R$ perdidos"
    v2: "Lista de R$ perdidos"
    v3: "6 cards de afirmações"
    v4: "6 cards de afirmações"
    v5: "Lista de R$ perdidos"
  COR_DESTAQUE:
    v1: "Laranja (#FF6B00)"
    v2: "Vermelho (#E53935)"
    v3: "Ciano (#00B4D8)"
    v4: "Amarelo (#FFB300)"
    v5: "Roxo (#7C3AED)"
  COPY_CTA:
    v1: "QUERO ME INSCREVER POR {TICKET_INGRESSO}"
    v2: "QUERO {RESULTADO_PRINCIPAL}"
    v3: "GARANTIR MINHA VAGA AGORA"
    v4: "QUERO TER {TRANSFORMACAO}"
    v5: "BORA TRANSFORMAR ISSO"
```

---

## 📊 Métricas-alvo (todas as variações)

```yaml
CONVERSAO_PAGINA_MIN:     "≥ 5%"
CONVERSAO_PAGINA_IDEAL:   "≥ 7%"
LCP_MAX:                  "< 1.5s"                        # mais rigoroso que padrão (≤2s)
INP_MAX:                  "< 200ms"
CLS_MAX:                  "< 0.05"                        # mais rigoroso que padrão (<0.1)
PESO_TOTAL_MAX:           "< 1 MB (mobile)"
PESO_HERO_IMG_MAX:        "< 150 KB (WebP/AVIF)"
LIGHTHOUSE_MIN:           "≥ 95 (mobile)"
```

---

## 📱 Mobile-first

```yaml
PRIORIDADE:               "Mobile sempre · desktop depois"
BREAKPOINT_BASE:          "375px (iPhone SE / mínimo)"
BREAKPOINTS:
  sm:                     "640px"
  md:                     "768px"
  lg:                     "1024px"
  xl:                     "1280px"
TAMANHO_FONTE_BASE:       "16px (não usar < 14px em nenhum lugar)"
ALTURA_BOTAO_MOBILE:      "≥ 56px (touch target Apple HIG)"
ESPACAMENTO_TOQUES:       "≥ 8px entre alvos clicáveis"
```

---

## 🔗 Tracking obrigatório

```yaml
META_PIXEL_ID:            "{META_PIXEL_ID}"
META_CAPI_TOKEN:          "{META_CAPI_TOKEN}"
GOOGLE_TAG_MANAGER:       "{GTM_ID}"
GOOGLE_ANALYTICS:         "{GA4_ID}"
EVENTOS_PADRAO:           "PageView · ViewContent · InitiateCheckout · Purchase"
UTMS_PROPAGADAS:          "Sim · todas as UTMs entram no checkout"
```

---

## 🌐 Domínio e estrutura de URL

```yaml
DOMINIO:                  "{SUBDOMINIO}.{DOMINIO_RAIZ}"   # Ex: lp.dominio.com.br
PADRAO_URL:               "{DOMINIO}/v{N}"                # Ex: lp.dominio.com.br/v3
HOMEPAGE_REDIRECT:        "redireciona / → /v{ATUAL}"     # Variação principal padrão
```
# 01 · Stack e Deploy

> Stack fixo do LPSG: **Next.js 14 + TypeScript + Tailwind CSS + Cloudflare Pages** (export estático). Sem inventar moda.

---

## 🎯 Por que esse stack?

| Critério | Por que Next.js + Tailwind + Cloudflare Pages |
|---|---|
| **Performance** | LCP < 1.5s out-of-the-box · página estática (HTML pronto) servida da rede da Cloudflare |
| **Mobile-first** | Tailwind facilita responsivo · Next.js otimiza bundle por rota |
| **Deploy em 1 comando** | `npx wrangler pages deploy out` → produção. Sem servidor, sem dor |
| **A/B testing por rota** | 5 rotas `/v1`…`/v5`, cada anúncio aponta pra uma · sem rebuild pra trocar |
| **SEO + Open Graph** | Metadata API do Next 14 + sharing automatic |
| **Analytics integrado** | Cloudflare Web Analytics · sem cookie · mede LCP, INP e CLS |
| **HTTPS automático** | Cert grátis com auto-renew |
| **CDN global** | Rede da Cloudflare (CDN global, HTTPS automático) |
| **Preview por branch** | Cada branch vira URL única (`<branch>.<projeto>.pages.dev`) — fácil pra validar antes de subir |

---

## 📦 Stack completo

```yaml
Framework:        Next.js 14 (App Router)
Linguagem:        TypeScript
CSS:              Tailwind CSS 4
Componentes UI:   shadcn/ui (opcional, pra acelerar)
Ícones:           lucide-react
Animações:        Framer Motion (mínimo · só se necessário)
Fontes:           Inter (Google Fonts) + Manrope (variable, peso único)
Hospedagem:       Cloudflare Pages (export estático · pasta out/)
Domínio:          Cloudflare DNS → Cloudflare Pages
Tracking:         Meta Pixel + CAPI · Google Tag Manager · GA4
Analytics:        Cloudflare Web Analytics
```

---

## 🚀 Setup inicial (15 minutos)

### 1. Criar projeto

```bash
pnpm create next-app@latest lpsg-pages \
  --typescript \
  --tailwind \
  --app \
  --src-dir \
  --import-alias "@/*"

cd lpsg-pages
pnpm install
```

### 2. Adicionar dependências

```bash
pnpm add lucide-react clsx tailwind-merge
pnpm add -D @types/node prettier prettier-plugin-tailwindcss
```

### 3. Configurar `next.config.ts`

```typescript
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "export",      // `npx next build` gera a pasta out/ (é ela que sobe no Cloudflare Pages)
  reactStrictMode: true,
  poweredByHeader: false,
  images: {
    unoptimized: true,   // export estático não tem otimizador de imagem: suba WebP/AVIF já otimizados
  },
};

export default nextConfig;
```

> Em export estático o Next **não** roda `redirects()` nem `headers()` do `next.config`. O redirect da home vai num arquivo `public/_redirects` (o build copia pra `out/`):

```
/  /v1  302
```

### 4. Configurar Tailwind tokens

`tailwind.config.ts`:

```typescript
import type { Config } from "tailwindcss";

export default {
  content: ["./src/**/*.{ts,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        bg: "#0A0A0A",          // fundo escuro
        "bg-card": "#141414",   // card escuro
        fg: "#FAFAFA",          // texto principal
        "fg-muted": "#A3A3A3",  // texto secundário
        accent: "var(--accent)", // cor de destaque dinâmica por variação
      },
      fontFamily: {
        sans: ["var(--font-inter)", "ui-sans-serif", "system-ui"],
        display: ["var(--font-manrope)", "ui-sans-serif"],
      },
    },
  },
} satisfies Config;
```

### 5. Configurar fontes

`src/app/layout.tsx`:

```tsx
import { Inter, Manrope } from "next/font/google";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const manrope = Manrope({
  subsets: ["latin"],
  variable: "--font-manrope",
  display: "swap",
});

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" className={`${inter.variable} ${manrope.variable}`}>
      <body className="bg-bg text-fg antialiased">{children}</body>
    </html>
  );
}
```

---

## 🚢 Deploy no Cloudflare Pages

### Primeira vez

1. Cria conta: [dash.cloudflare.com](https://dash.cloudflare.com) (o plano grátis resolve)
2. Na raiz do projeto, cria o projeto Pages (uma vez só):

```bash
npx wrangler pages project create {projeto} --production-branch main
```

3. Gera o build e publica:

```bash
npx next build
npx wrangler pages deploy out --project-name {projeto} --branch main
```

4. A URL `https://{projeto}.pages.dev` está no ar

> **Opcional · deploy automático no `git push`:** Cloudflare → Workers & Pages → Create → Pages → conectar o repositório Git. Build command `npx next build`, build directory `out`.

### Variáveis de ambiente

Configurar em `Workers & Pages → projeto → Settings → Variables and Secrets`:

```
NEXT_PUBLIC_META_PIXEL_ID         = {SEU_PIXEL_ID}
NEXT_PUBLIC_GTM_ID                = GTM-XXXXXXX
NEXT_PUBLIC_GA4_ID                = G-XXXXXXXXXX
META_CAPI_TOKEN                   = {SEU_CAPI_TOKEN}        # secret · não NEXT_PUBLIC_
NEXT_PUBLIC_CHECKOUT_URL          = https://pay.hotmart.com/...
```

> As `NEXT_PUBLIC_*` entram no build (são públicas, vão no HTML). Segredo (token Meta/Hotmart) **nunca** é `NEXT_PUBLIC_`: vai como segredo do projeto e só é lido por Pages Functions (`functions/api/<nome>.js`, ver `08-ficha-interesse.md`):

```bash
npx wrangler pages secret put META_CAPI_TOKEN --project-name {projeto}
```

### Domínio customizado

1. **Primeiro** associa o domínio no projeto: `Workers & Pages → projeto → Custom domains → Set up a domain`
2. **Depois** aponta o DNS: `CNAME lp → {projeto}.pages.dev` (zona já na Cloudflare: o próprio painel cria o registro)
3. HTTPS automático

> CNAME criado **antes** de associar o domínio no projeto = domínio não resolve (erro 522).

### Branches e preview

| Branch | URL | Função |
|---|---|---|
| `main` | `lp.{dominio}.com.br` | Produção |
| `dev` | `https://dev.{projeto}.pages.dev` | Staging |
| `feature-x` | `https://feature-x.{projeto}.pages.dev` | Preview |

```bash
npx wrangler pages deploy out --project-name {projeto} --branch feature-x
```

> Cada branch vira uma URL preview (minúsculas, caractere fora de letra/número vira hífen) — manda pro time validar antes de subir pra `main`.

---

## 🔧 A/B testing (por rota)

O A/B do LPSG é por **rota**, não por configuração em runtime:

1. As 5 variações já existem como rotas `/v1`…`/v5`
2. Cada anúncio aponta pra uma rota
3. Trocar a variação principal = trocar a linha do `public/_redirects` e publicar de novo
4. Precisa dividir tráfego na borda (mesma URL, variações diferentes)? Pages Functions: arquivo `functions/_middleware.js` exportando `onRequest`

---

## 📊 Cloudflare Web Analytics

Ativa grátis em `Workers & Pages → projeto → Metrics → Enable (Web Analytics)`. Não precisa instalar pacote nem mexer no `layout.tsx`. Sem cookie e sem localStorage (sem banner de consentimento).

Métricas que vão aparecer no painel da Cloudflare:
- Page views por rota (`/v1`, `/v2`...)
- Top pages
- Top referrers
- LCP/INP/CLS (Core Web Vitals)

---

## 🚫 O que NÃO usar

| Tecnologia | Por quê |
|---|---|
| **WordPress / Elementor / similares** | LCP > 4s · plugins inflam bundle · ranking SEO ruim · vetor de ataque |
| **Bootstrap** | Bundle gigante · CSS antigo · Tailwind mais flexível |
| **Material UI / Chakra** | 200KB+ de runtime · não vale pra LP |
| **GSAP** | Pesado · use Framer Motion ou animação CSS pura |
| **Imagens não otimizadas** | Sempre WebP/AVIF (converter antes de subir) via `next/image` |
| **Vídeo no hero** | Adia LCP · LPSG não usa VSL no topo |
| **Pop-ups de carregamento** | Meta Ads pode bloquear |

---

## 📋 Checklist de setup

- [ ] Repo Git criado (GitHub/GitLab/Bitbucket)
- [ ] `pnpm create next-app` rodado
- [ ] `next.config.ts` com `output: "export"` e `images.unoptimized` · `public/_redirects` com `/ → /v1`
- [ ] Tailwind tokens definidos (cores, fontes)
- [ ] Fontes Inter + Manrope via `next/font/google`
- [ ] `.env.local` com todas as variáveis (não commitar)
- [ ] Projeto Pages criado e deploy inicial (`wrangler pages deploy out`) concluído
- [ ] Domínio customizado apontado
- [ ] Cloudflare Web Analytics ativo
- [ ] Pixel + GTM + GA4 instalados e validados
- [ ] Preview por branch testado (`--branch` vira URL)
# 02 · Arquitetura do Projeto

> Como organizar arquivos, rotas e dados pra rodar 5 variações sem duplicar código.

---

## 📁 Estrutura de pastas

```
{NOME_PROJETO}/
├── public/
│   ├── images/
│   │   ├── expert.webp                 ← foto do expert (única, otimizada)
│   │   ├── alunos/                     ← prints/fotos dos depoimentos
│   │   └── og-image.jpg                ← Open Graph (1200x630)
│   ├── favicon.ico
│   └── robots.txt
│
├── src/
│   ├── app/
│   │   ├── layout.tsx                  ← layout raiz (fontes + analytics)
│   │   ├── page.tsx                    ← redireciona pra /v1
│   │   ├── globals.css                 ← reset + Tailwind base
│   │   ├── (variations)/               ← grupo de rotas das variações
│   │   │   ├── v1/page.tsx
│   │   │   ├── v2/page.tsx
│   │   │   ├── v3/page.tsx
│   │   │   ├── v4/page.tsx
│   │   │   └── v5/page.tsx
│   │   └── obrigado/page.tsx           ← thank you page (pós-checkout)
│   │
│   ├── components/
│   │   ├── blocks/                     ← os 9 blocos da página
│   │   │   ├── TopBar.tsx              ← barra de urgência
│   │   │   ├── Hero.tsx                ← headline + foto + CTA + garantia
│   │   │   ├── Pain.tsx                ← amplificação da dor
│   │   │   ├── NotYourFault.tsx        ← "a culpa não é sua"
│   │   │   ├── Authority.tsx           ← origem do expert
│   │   │   ├── Promises.tsx            ← promessas expandidas
│   │   │   ├── Lessons.tsx             ← o que vai aprender
│   │   │   ├── Testimonials.tsx        ← prova social
│   │   │   └── FinalCTA.tsx            ← CTA final + urgência
│   │   ├── ui/
│   │   │   ├── Button.tsx              ← componente de botão CTA
│   │   │   ├── Container.tsx           ← wrapper com largura máxima
│   │   │   └── GuaranteeBadge.tsx      ← bloco de garantia
│   │   └── tracking/
│   │       ├── MetaPixel.tsx           ← script do pixel
│   │       └── GTM.tsx                 ← script do GTM
│   │
│   ├── data/
│   │   ├── variations.ts               ← definições das 5 variações (SOURCE OF TRUTH)
│   │   ├── testimonials.ts             ← lista de depoimentos
│   │   ├── lessons.ts                  ← lista das 5+1 aulas
│   │   ├── pains.ts                    ← lista de dores
│   │   └── promises.ts                 ← lista de promessas
│   │
│   ├── lib/
│   │   ├── tracking.ts                 ← envio de eventos pixel/GA
│   │   ├── utils.ts                    ← clsx, cn, helpers
│   │   └── constants.ts                ← URLs, IDs
│   │
│   └── styles/
│       └── theme.css                   ← variáveis CSS por variação (cores)
│
├── .env.local                           ← variáveis (não commitar)
├── .env.example                         ← template
├── .gitignore
├── next.config.ts
├── tailwind.config.ts
├── tsconfig.json
├── package.json
└── README.md
```

---

## 🛣️ Rotas e variações

### URL final em produção

```
https://lp.{DOMINIO}.com.br/      ← redireciona pra /v1
https://lp.{DOMINIO}.com.br/v1    ← variação 1
https://lp.{DOMINIO}.com.br/v2    ← variação 2
https://lp.{DOMINIO}.com.br/v3    ← variação 3
https://lp.{DOMINIO}.com.br/v4    ← variação 4
https://lp.{DOMINIO}.com.br/v5    ← variação 5
```

### Como cada `page.tsx` é estruturada

```tsx
// src/app/(variations)/v1/page.tsx

import { getVariation } from "@/data/variations";
import { TopBar } from "@/components/blocks/TopBar";
import { Hero } from "@/components/blocks/Hero";
import { Pain } from "@/components/blocks/Pain";
import { NotYourFault } from "@/components/blocks/NotYourFault";
import { Authority } from "@/components/blocks/Authority";
import { Promises } from "@/components/blocks/Promises";
import { Lessons } from "@/components/blocks/Lessons";
import { Testimonials } from "@/components/blocks/Testimonials";
import { FinalCTA } from "@/components/blocks/FinalCTA";

export const metadata = {
  title: "{TITULO_PADRAO}",
  description: "{DESC_PADRAO}",
};

export default function V1Page() {
  const variation = getVariation("v1");
  return (
    <main style={{ "--accent": variation.accentColor } as React.CSSProperties}>
      <TopBar variation={variation} />
      <Hero variation={variation} />
      <Pain variation={variation} />
      <NotYourFault variation={variation} />
      <Authority variation={variation} />
      <Promises variation={variation} />
      <Lessons variation={variation} />
      <Testimonials variation={variation} />
      <FinalCTA variation={variation} />
    </main>
  );
}
```

### Por que esse padrão?

- **Componentes idênticos** entre variações (1 source of truth por bloco)
- **Variação muda apenas dados** (headline, dor, cor, CTA) — não estrutura
- **Manutenção centralizada** — corrigiu 1 bloco, arruma nas 5 variações
- **Fácil adicionar v6, v7...** — copia pasta, ajusta `data/variations.ts`

---

## 📦 `data/variations.ts` — fonte da verdade

```typescript
// src/data/variations.ts

export type VariationId = "v1" | "v2" | "v3" | "v4" | "v5";

export type Variation = {
  id: VariationId;

  // HERO
  headline: string;
  subHeadline: string;
  heroImage: string;          // path da imagem do expert

  // DATA E HORÁRIO (mesmo pra todas)
  dateText: string;           // "De 12/05 a 18/05 · Sempre às 7h"

  // CTA
  ctaPrimary: string;         // texto do botão hero
  ctaSecondary: string;       // texto do botão final
  checkoutUrl: string;

  // VISUAL
  accentColor: string;        // cor de destaque (CSS)
  topBarText: string;         // "VAGAS SE ESGOTANDO" / "ÚLTIMOS 10%"

  // ESTRUTURA DE DOR
  painType: "money-list" | "affirmations";  // que tipo de bloco usar
  painHeadline: string;
};

export const variations: Record<VariationId, Variation> = {
  v1: {
    id: "v1",
    headline: "{HEADLINE_V1}",                  // Pergunta polêmica
    subHeadline: "{SUB_V1}",
    heroImage: "/images/expert.webp",
    dateText: "De {DATA_INICIO} a {DATA_FIM} · Sempre às {HORARIO}",
    ctaPrimary: "QUERO ME INSCREVER POR {TICKET_INGRESSO}",
    ctaSecondary: "GARANTIR MEU INGRESSO",
    checkoutUrl: process.env.NEXT_PUBLIC_CHECKOUT_URL!,
    accentColor: "oklch(70% 0.20 50)",          // laranja #FF6B00
    topBarText: "🔥 VAGAS SE ESGOTANDO",
    painType: "money-list",
    painHeadline: "VOCÊ NÃO TEM IDEIA DO PESADELO!",
  },
  v2: {
    id: "v2",
    headline: "{HEADLINE_V2}",                  // Prova em números
    subHeadline: "{SUB_V2}",
    heroImage: "/images/expert.webp",
    dateText: "De {DATA_INICIO} a {DATA_FIM} · Sempre às {HORARIO}",
    ctaPrimary: "QUERO {RESULTADO_PRINCIPAL}",
    ctaSecondary: "GARANTIR MEU INGRESSO",
    checkoutUrl: process.env.NEXT_PUBLIC_CHECKOUT_URL!,
    accentColor: "oklch(60% 0.22 25)",          // vermelho #E53935
    topBarText: "🔥 71% PREENCHIDO",
    painType: "money-list",
    painHeadline: "QUANTO CUSTA NÃO AGIR?",
  },
  v3: {
    id: "v3",
    headline: "{HEADLINE_V3}",                  // Contra-intuitiva
    subHeadline: "{SUB_V3}",
    heroImage: "/images/expert.webp",
    dateText: "De {DATA_INICIO} a {DATA_FIM} · Sempre às {HORARIO}",
    ctaPrimary: "GARANTIR MINHA VAGA AGORA",
    ctaSecondary: "QUERO ENTRAR",
    checkoutUrl: process.env.NEXT_PUBLIC_CHECKOUT_URL!,
    accentColor: "oklch(70% 0.15 220)",         // ciano #00B4D8
    topBarText: "🔥 ÚLTIMOS DIAS",
    painType: "affirmations",
    painHeadline: "{AVATAR}, alguma dessas afirmações te incomoda?",
  },
  v4: {
    id: "v4",
    headline: "{HEADLINE_V4}",                  // Antes vs depois
    subHeadline: "{SUB_V4}",
    heroImage: "/images/expert.webp",
    dateText: "De {DATA_INICIO} a {DATA_FIM} · Sempre às {HORARIO}",
    ctaPrimary: "QUERO TER {TRANSFORMACAO}",
    ctaSecondary: "QUERO ESSE RESULTADO",
    checkoutUrl: process.env.NEXT_PUBLIC_CHECKOUT_URL!,
    accentColor: "oklch(80% 0.18 90)",          // amarelo #FFB300
    topBarText: "🔥 INSCRIÇÕES ABERTAS",
    painType: "affirmations",
    painHeadline: "Reconhece sua situação atual?",
  },
  v5: {
    id: "v5",
    headline: "{HEADLINE_V5}",                  // Confissão
    subHeadline: "{SUB_V5}",
    heroImage: "/images/expert.webp",
    dateText: "De {DATA_INICIO} a {DATA_FIM} · Sempre às {HORARIO}",
    ctaPrimary: "BORA TRANSFORMAR ISSO",
    ctaSecondary: "ME INSCREVER",
    checkoutUrl: process.env.NEXT_PUBLIC_CHECKOUT_URL!,
    accentColor: "oklch(60% 0.20 290)",         // roxo #7C3AED
    topBarText: "🔥 TURMA NOVA",
    painType: "money-list",
    painHeadline: "EU JÁ ESTIVE NESSA SITUAÇÃO...",
  },
};

export function getVariation(id: VariationId): Variation {
  return variations[id];
}
```

---

## 📊 Outros arquivos de dados (compartilhados entre variações)

### `data/lessons.ts`

```typescript
export const lessons = [
  {
    n: 1,
    icon: "🔓",
    title: "{TITULO_PUBLICO_AULA_1}",
    description: "{1_LINHA}",
  },
  // ... 5+1 aulas
];
```

### `data/testimonials.ts`

```typescript
export type Testimonial = {
  id: string;
  type: "video" | "text" | "screenshot";
  name: string;
  cityOrProfession: string;
  result: string;            // "R$ 47k em 90 dias"
  emotional: string;         // "parei de ter insônia"
  mediaUrl?: string;         // foto/vídeo/print
  videoEmbed?: string;       // ID do vídeo
};

export const testimonials: Testimonial[] = [
  // mínimo 6 depoimentos
];
```

### `data/pains.ts`

```typescript
export const moneyPains = [
  { label: "{ERRO_1}", cost: "+ R$ 90.000,00" },
  { label: "{ERRO_2}", cost: "+ R$ 30.000,00" },
  // 4-6 itens
];

export const affirmationPains = [
  { icon: "✗", title: "{DOR_1}", description: "{1_LINHA}" },
  // 6 itens
];
```

### `data/promises.ts`

```typescript
export const promises = [
  { icon: "✓", text: "{TRANSFORMACAO_1}" },
  // 4-6 itens
];
```

---

## 🎨 Cor de destaque dinâmica (CSS variable)

Cada variação injeta `--accent` no root via inline style.

`globals.css`:

```css
:root {
  --accent: oklch(70% 0.20 50); /* fallback laranja */
}

.bg-accent { background-color: var(--accent); }
.text-accent { color: var(--accent); }
.border-accent { border-color: var(--accent); }
```

Componentes usam `bg-accent` / `text-accent` — cor muda por variação sem trocar classe.

---

## 🔁 Quando criar v6, v7...

1. Cria `src/app/(variations)/v6/page.tsx` (copia da v1, troca `getVariation("v1")` por `"v6"`)
2. Adiciona entrada em `data/variations.ts`
3. Atualiza tipo `VariationId`
4. Publica de novo: `npx next build` + `npx wrangler pages deploy out --project-name <projeto> --branch main` (ou automático no `git push`, se o repositório estiver conectado no Cloudflare Pages)

> **Manutenção é trivial** porque o esqueleto da página é igual entre variações.

---

## 📋 Checklist de arquitetura

- [ ] Estrutura de pastas seguindo o padrão acima
- [ ] 5 rotas `/v1` a `/v5` criadas
- [ ] Homepage `/` redireciona pra `/v1` (ou variação principal)
- [ ] `data/variations.ts` com todas as 5 variações tipadas
- [ ] Componentes em `components/blocks/` com prop `variation`
- [ ] Cor de destaque via CSS variable `--accent`
- [ ] Imagens em `public/images/` otimizadas (WebP/AVIF)
- [ ] Open Graph image criada (`og-image.jpg` 1200x630)
- [ ] Tracking centralizado em `lib/tracking.ts`
# 03 · Componentes Mobile-First

> Cada um dos **9 blocos** da página vira um componente React. Tudo mobile-first. Aqui o esqueleto pronto pra copiar.

---

## 📱 Princípios mobile-first

| # | Princípio |
|---|---|
| 1 | **Tamanho de fonte mínimo: 16px** — abaixo disso, mobile faz zoom no input |
| 2 | **Botões com altura ≥ 56px** — touch target Apple HIG |
| 3 | **Espaçamento vertical entre seções: 64-96px** (`py-16` a `py-24`) |
| 4 | **Largura máxima de texto: 65 caracteres** (legibilidade) |
| 5 | **Imagens com `loading="lazy"`** exceto a do hero (`priority`) |
| 6 | **Sem hover-only** — todo estado também acessível por toque |
| 7 | **Contraste de texto ≥ 4.5:1** (WCAG AA) |
| 8 | **`viewport-fit=cover`** no `<meta viewport>` pra notch do iPhone |

---

## 🧱 Os 9 blocos como componentes

### 1️⃣ TopBar — Barra de urgência

```tsx
// src/components/blocks/TopBar.tsx
import { Variation } from "@/data/variations";

export function TopBar({ variation }: { variation: Variation }) {
  return (
    <div className="sticky top-0 z-50 w-full bg-bg-card border-b border-white/10 py-2 px-4">
      <p className="text-center text-sm font-semibold text-accent">
        {variation.topBarText}
      </p>
    </div>
  );
}
```

---

### 2️⃣ Hero — A primeira dobra

```tsx
// src/components/blocks/Hero.tsx
import Image from "next/image";
import { Variation } from "@/data/variations";
import { Button } from "@/components/ui/Button";
import { GuaranteeBadge } from "@/components/ui/GuaranteeBadge";

export function Hero({ variation }: { variation: Variation }) {
  return (
    <section className="relative px-5 py-12 md:py-20">
      <div className="mx-auto max-w-6xl flex flex-col md:flex-row items-center gap-8 md:gap-12">
        {/* Coluna texto */}
        <div className="flex-1 order-2 md:order-1">
          <h1 className="font-display text-4xl md:text-6xl font-black leading-tight">
            {variation.headline}
          </h1>

          <p className="mt-4 text-lg md:text-xl text-fg-muted">
            {variation.subHeadline}
          </p>

          {/* DATA DO EVENTO — obrigatória na primeira dobra */}
          <div className="mt-6 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/30">
            <span className="text-base">📅</span>
            <span className="text-sm md:text-base font-semibold text-accent">
              {variation.dateText}
            </span>
          </div>

          {/* CTA */}
          <Button
            href={variation.checkoutUrl}
            size="lg"
            className="mt-6 w-full md:w-auto"
          >
            {variation.ctaPrimary}
          </Button>

          {/* GARANTIA — obrigatória abaixo do botão */}
          <GuaranteeBadge className="mt-4" />

          {/* Linha de prova */}
          <p className="mt-6 text-sm text-fg-muted">
            ⭐ +{"{N_ALUNOS}"} alunos transformados
          </p>
        </div>

        {/* Foto do expert */}
        <div className="flex-1 order-1 md:order-2 w-full">
          <Image
            src={variation.heroImage}
            alt="{NOME_ESPECIALISTA}"
            width={600}
            height={600}
            priority
            className="rounded-2xl w-full h-auto object-cover"
          />
        </div>
      </div>
    </section>
  );
}
```

---

### 3️⃣ Pain — Amplificação da dor

Suporta 2 estilos: `money-list` (lista de R$) e `affirmations` (cards de dores).

```tsx
// src/components/blocks/Pain.tsx
import { Variation } from "@/data/variations";
import { moneyPains, affirmationPains } from "@/data/pains";

export function Pain({ variation }: { variation: Variation }) {
  return (
    <section className="px-5 py-16 md:py-24 bg-bg-card">
      <div className="mx-auto max-w-4xl">
        <h2 className="font-display text-3xl md:text-5xl font-black uppercase tracking-tight">
          {variation.painHeadline}
        </h2>

        {variation.painType === "money-list" ? (
          <ul className="mt-8 space-y-3">
            {moneyPains.map((p) => (
              <li
                key={p.label}
                className="flex items-baseline justify-between gap-4 py-3 border-b border-white/10"
              >
                <span className="text-base md:text-lg">❌ {p.label}</span>
                <span className="font-mono font-bold text-accent">{p.cost}</span>
              </li>
            ))}
          </ul>
        ) : (
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-4">
            {affirmationPains.map((p) => (
              <div
                key={p.title}
                className="p-5 rounded-xl bg-bg border border-white/10"
              >
                <p className="text-2xl">{p.icon}</p>
                <h3 className="mt-2 font-bold text-lg">{p.title}</h3>
                <p className="mt-1 text-sm text-fg-muted">{p.description}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
```

---

### 4️⃣ NotYourFault — "A culpa não é sua"

```tsx
// src/components/blocks/NotYourFault.tsx
export function NotYourFault({ variation }: { variation: Variation }) {
  return (
    <section className="px-5 py-16 md:py-24">
      <div className="mx-auto max-w-3xl text-center">
        <p className="text-sm font-bold tracking-widest text-accent uppercase">
          ATENÇÃO
        </p>
        <h2 className="mt-2 font-display text-3xl md:text-5xl font-black">
          A culpa não é sua.
        </h2>
        <p className="mt-6 text-lg leading-relaxed text-fg-muted">
          {/* Substitua pelo texto da variação */}
          Sabe por quê? Porque {"{EXPLICACAO_DO_SISTEMA_QUEBRADO}"}.
          {" "}
          {"{DETALHE_DO_PROBLEMA_MAIOR}"}.
        </p>
      </div>
    </section>
  );
}
```

---

### 5️⃣ Authority — Origem do expert

```tsx
// src/components/blocks/Authority.tsx
import Image from "next/image";

export function Authority({ variation }: { variation: Variation }) {
  return (
    <section className="px-5 py-16 md:py-24 bg-bg-card">
      <div className="mx-auto max-w-5xl flex flex-col md:flex-row items-center gap-8">
        <div className="md:w-1/3">
          <Image
            src="/images/expert-portrait.webp"
            alt="{NOME_ESPECIALISTA}"
            width={400}
            height={500}
            loading="lazy"
            className="rounded-xl w-full h-auto"
          />
        </div>

        <div className="md:w-2/3">
          <h2 className="font-display text-3xl md:text-4xl font-black">
            Eu errei MUITO pra você acertar 100%
          </h2>
          <div className="mt-4 space-y-3 text-base md:text-lg text-fg-muted">
            <p>{"{HISTORIA_PARAGRAFO_1}"}</p>
            <p>{"{HISTORIA_PARAGRAFO_2}"}</p>
          </div>

          <ul className="mt-6 grid grid-cols-2 gap-3 text-sm">
            <li>✓ {"{CREDENCIAL_1}"}</li>
            <li>✓ {"{CREDENCIAL_2}"}</li>
            <li>✓ {"{CREDENCIAL_3}"}</li>
            <li>✓ {"{CREDENCIAL_4}"}</li>
          </ul>
        </div>
      </div>
    </section>
  );
}
```

---

### 6️⃣ Promises — Promessas expandidas

```tsx
// src/components/blocks/Promises.tsx
import { promises } from "@/data/promises";

export function Promises() {
  return (
    <section className="px-5 py-16 md:py-24">
      <div className="mx-auto max-w-4xl">
        <h2 className="font-display text-3xl md:text-5xl font-black uppercase text-center">
          O que muda quando você domina o método:
        </h2>

        <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-4">
          {promises.map((p) => (
            <div
              key={p.text}
              className="flex items-start gap-3 p-4 rounded-xl bg-bg-card border border-white/10"
            >
              <span className="text-2xl text-accent flex-shrink-0">{p.icon}</span>
              <p className="text-base md:text-lg">{p.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
```

---

### 7️⃣ Lessons — O que vai aprender

```tsx
// src/components/blocks/Lessons.tsx
import { lessons } from "@/data/lessons";

export function Lessons() {
  return (
    <section className="px-5 py-16 md:py-24 bg-bg-card">
      <div className="mx-auto max-w-4xl">
        <h2 className="font-display text-3xl md:text-5xl font-black uppercase text-center">
          O que você vai aprender
        </h2>

        <ol className="mt-10 space-y-4">
          {lessons.map((l) => (
            <li
              key={l.n}
              className="flex items-start gap-4 p-5 rounded-xl bg-bg border border-white/10"
            >
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center text-accent font-black text-xl">
                {l.n}
              </div>
              <div>
                <h3 className="font-bold text-lg md:text-xl">
                  {l.icon} {l.title}
                </h3>
                <p className="mt-1 text-sm md:text-base text-fg-muted">
                  {l.description}
                </p>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
```

---

### 8️⃣ Testimonials — Prova social massiva

```tsx
// src/components/blocks/Testimonials.tsx
import Image from "next/image";
import { testimonials } from "@/data/testimonials";

export function Testimonials() {
  return (
    <section className="px-5 py-16 md:py-24">
      <div className="mx-auto max-w-6xl">
        <h2 className="font-display text-3xl md:text-5xl font-black uppercase text-center">
          É IMPOSSÍVEL NEGAR OS RESULTADOS
        </h2>
        <p className="mt-3 text-center text-fg-muted text-lg">
          Veja o que os alunos estão dizendo:
        </p>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((t) => (
            <article
              key={t.id}
              className="p-5 rounded-2xl bg-bg-card border border-white/10"
            >
              {t.type === "video" && t.videoEmbed && (
                <div className="aspect-[9/16] rounded-xl overflow-hidden bg-black">
                  <iframe
                    src={t.videoEmbed}
                    loading="lazy"
                    className="w-full h-full"
                    allowFullScreen
                  />
                </div>
              )}

              {t.type === "screenshot" && t.mediaUrl && (
                <Image
                  src={t.mediaUrl}
                  alt={`Resultado ${t.name}`}
                  width={500}
                  height={500}
                  loading="lazy"
                  className="rounded-xl w-full h-auto"
                />
              )}

              <h3 className="mt-4 font-black text-sm md:text-base uppercase text-accent">
                {t.result}
              </h3>
              <p className="mt-2 text-base">"{t.emotional}"</p>
              <p className="mt-3 text-sm text-fg-muted">
                — {t.name}, {t.cityOrProfession}
              </p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
```

---

### 9️⃣ FinalCTA — Última chamada

```tsx
// src/components/blocks/FinalCTA.tsx
import { Variation } from "@/data/variations";
import { Button } from "@/components/ui/Button";
import { GuaranteeBadge } from "@/components/ui/GuaranteeBadge";

export function FinalCTA({ variation }: { variation: Variation }) {
  return (
    <section className="px-5 py-16 md:py-24 bg-gradient-to-b from-bg to-bg-card">
      <div className="mx-auto max-w-3xl text-center">
        <p className="text-sm font-bold tracking-widest text-accent uppercase">
          ÚLTIMA CHAMADA
        </p>

        <h2 className="mt-2 font-display text-3xl md:text-5xl font-black">
          {variation.painHeadline.includes("?") ? "É agora ou nunca" : "Sua escolha"}
        </h2>

        <p className="mt-4 text-lg text-fg-muted">{variation.dateText}</p>

        <Button
          href={variation.checkoutUrl}
          size="lg"
          className="mt-8 w-full md:w-auto"
        >
          {variation.ctaSecondary}
        </Button>

        <GuaranteeBadge className="mt-4" />

        <ul className="mt-8 space-y-2 text-sm text-fg-muted">
          <li>✓ Acesso imediato após confirmação</li>
          <li>✓ Aulas ao vivo + gravadas</li>
          <li>✓ Suporte direto pelo WhatsApp</li>
        </ul>
      </div>
    </section>
  );
}
```

---

## 🎁 Componentes UI auxiliares

### `Button.tsx`

```tsx
// src/components/ui/Button.tsx
import Link from "next/link";
import { cn } from "@/lib/utils";

type Props = {
  href: string;
  children: React.ReactNode;
  size?: "md" | "lg";
  className?: string;
};

export function Button({ href, children, size = "md", className }: Props) {
  return (
    <Link
      href={href}
      className={cn(
        "inline-flex items-center justify-center font-black uppercase tracking-wide rounded-xl transition-all",
        "bg-accent text-bg hover:scale-[1.02] active:scale-[0.98]",
        size === "lg" ? "min-h-[56px] px-8 text-base md:text-lg" : "min-h-[44px] px-6 text-sm",
        className
      )}
    >
      {children}
    </Link>
  );
}
```

### `GuaranteeBadge.tsx`

```tsx
// src/components/ui/GuaranteeBadge.tsx
import { cn } from "@/lib/utils";

export function GuaranteeBadge({ className }: { className?: string }) {
  return (
    <div className={cn("flex items-start gap-2 text-sm text-fg-muted", className)}>
      <span className="text-base flex-shrink-0">🛡️</span>
      <p className="text-left">
        <strong className="text-fg">Garantia Incondicional: Assista!</strong>
        <br />
        Se não gostar devolvo seu dinheiro ao final do evento.
      </p>
    </div>
  );
}
```

### `lib/utils.ts`

```typescript
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
```

---

## 🎨 Tailwind classes-padrão do LPSG

| Elemento | Classe |
|---|---|
| Container | `mx-auto max-w-6xl px-5` |
| Seção padrão | `px-5 py-16 md:py-24` |
| Headline H1 | `font-display text-4xl md:text-6xl font-black leading-tight` |
| Headline H2 | `font-display text-3xl md:text-5xl font-black uppercase` |
| Texto corpo | `text-base md:text-lg leading-relaxed text-fg-muted` |
| Botão CTA | `min-h-[56px] px-8 font-black uppercase rounded-xl bg-accent` |
| Card | `p-5 rounded-xl bg-bg-card border border-white/10` |

---

## 🚫 Erros comuns

| Erro | Consequência mobile |
|---|---|
| Fonte < 14px | Ilegível · Apple zoom em inputs |
| Botão < 44px de altura | Difícil tocar · taxa de erro alta |
| Imagens sem `next/image` | Sem otimização · LCP péssimo |
| Hero sem `priority` | LCP alto · perde mobile |
| Múltiplos H1 | SEO ruim · acessibilidade ruim |
| `<input>` sem `type` correto | Teclado errado · UX ruim |
| `position: fixed` sem cuidado | Quebra com teclado virtual |
| Modal sem `inert` | Foco escapa por trás |
| Animação heavy | INP > 200ms · perde Core Web Vitals |
| Sem `aria-label` em ícones | Screen reader ignora |

---

## 📋 Checklist de componentes

- [ ] 9 blocos criados em `components/blocks/`
- [ ] 2 componentes UI (Button + GuaranteeBadge)
- [ ] `lib/utils.ts` com helper `cn`
- [ ] Todos os componentes recebem prop `variation` quando relevante
- [ ] Hero usa `<Image priority>` (LCP)
- [ ] Outras imagens usam `loading="lazy"`
- [ ] Botões com `min-h-[56px]` no mobile
- [ ] Fonte mínima 16px no body
- [ ] Cores via `bg-accent` / `text-accent` (CSS variable)
- [ ] Espaçamento vertical consistente (`py-16 md:py-24`)
- [ ] Tudo responsivo (testar em 375px de largura)
# 04 · Matriz das 5 Variações

> Mínimo **5 variações** por projeto. Mesmo esqueleto, dados diferentes. Eixos: **headline · estrutura de dor · cor de destaque · CTA**.

---

## 🎯 Por que 5 variações?

- **Estatística:** menos que 5 → ruído maior que sinal
- **Hipóteses isoladas:** cada variação testa um eixo de hipótese
- **Velocidade:** roda 5 em paralelo em campanhas de teste · 1 sai vencedora em 7-10 dias
- **Aprendizado acumulado:** vencedora vira "principal" · perdedoras viram banco de aprendizagem
- **Sem trocar tudo de uma vez:** próxima rodada mantém vencedora e testa novas variações dos elementos perdedores

---

## 📊 Matriz padrão dos 4 eixos

| Variação | Headline | Estrutura de dor | Cor destaque | CTA primário |
|---|---|---|---|---|
| **v1** | Pergunta polêmica | Lista R$ perdidos | Laranja `#FF6B00` | "QUERO ME INSCREVER POR {TICKET}" |
| **v2** | Prova em números | Lista R$ perdidos | Vermelho `#E53935` | "QUERO {RESULTADO_PRINCIPAL}" |
| **v3** | Declaração contra-intuitiva | 6 cards de afirmações | Ciano `#00B4D8` | "GARANTIR MINHA VAGA AGORA" |
| **v4** | Antes vs depois | 6 cards de afirmações | Amarelo `#FFB300` | "QUERO TER {TRANSFORMACAO}" |
| **v5** | Confissão / vulnerabilidade | Lista R$ perdidos | Roxo `#7C3AED` | "BORA TRANSFORMAR ISSO" |

---

## 1️⃣ Eixo 1 — Headline (5 tipos de hook)

### v1 — Pergunta polêmica

**Estrutura:** *"Por que {CRENCA_COMUM} é mentira?"*

**Quando funciona:** avatar com objeção forte e ceticismo · nichos saturados de promessas iguais.

**Exemplos:**
- *"Por que acordar cedo é o pior conselho pra quem quer fazer dinheiro?"*
- *"Por que CPL gratuito está te falindo (e ninguém te conta)?"*

### v2 — Prova em números

**Estrutura:** *"{NUMERO_ESPECÍFICO} — e aqui está o que ninguém te conta"*

**Quando funciona:** avatar racional · executivo · busca evidência antes de acreditar.

**Exemplos:**
- *"5.165 leads pagaram pelo meu tráfego mês passado. Zero CPL queimado."*
- *"R$ 1.847.293 em 90 dias com este mesmo método."*

### v3 — Declaração contra-intuitiva

**Estrutura:** *"Todo mundo fala que {X}. Tá errado."*

**Quando funciona:** avatar saturado de conteúdo igual · quer "atalho diferente".

**Exemplos:**
- *"Todo mundo fala que lançamento gratuito escala. Tá errado."*
- *"Pare de fazer dieta. É isso que está te engordando."*

### v4 — Antes vs depois

**Estrutura:** transformação visual + headline curta

**Quando funciona:** avatar visual · resultado tangível e mensurável.

**Exemplos:**
- *"De R$ 8k pra R$ 80k em 6 meses — sem aumentar a equipe."*
- *"De 25% body fat pra 12% em 90 dias."*

### v5 — Confissão / vulnerabilidade

**Estrutura:** *"Eu errei muito antes de descobrir isso."*

**Quando funciona:** avatar emocional · busca conexão antes de comprar.

**Exemplos:**
- *"Quase fechei minha empresa por causa disso. Hoje uso a favor."*
- *"Eu fui um péssimo aluno. Esse método salvou minha vida."*

---

## 2️⃣ Eixo 2 — Estrutura de dor

### Estilo A — Lista de R$ perdidos (v1, v2, v5)

**Quando usar:** dor é **financeira mensurável** (construção, business, marketing, trade).

**Estrutura visual:**

```
VOCÊ NÃO TEM IDEIA DO PESADELO!

❌ {ERRO_1}                 + R$ 90.000,00
❌ {ERRO_2}                 + R$ 30.000,00
❌ {ERRO_3}                 + R$ 28.000,00
❌ {ERRO_4}                 + R$ 9.000,00
─────────────────────────────────────────
TOTAL                       + R$ 157.000,00
```

**Regras:**
- Mínimo 4 linhas · ideal 6
- Valores em R$ específicos (não "muito dinheiro")
- Soma final em destaque visual

### Estilo B — 6 cards de afirmações (v3, v4)

**Quando usar:** dor é **emocional ou comportamental** (saúde, terapia, relacionamento).

**Estrutura visual:**

```
{AVATAR}, alguma das afirmações abaixo te incomoda?

┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
│ Carreira         │  │ Frustração       │  │ Insegurança      │
│ estagnada        │  │ técnica          │  │ clínica          │
│ {1_LINHA}        │  │ {1_LINHA}        │  │ {1_LINHA}        │
└──────────────────┘  └──────────────────┘  └──────────────────┘
┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
│ Sem protocolo    │  │ Preso a          │  │ Desatualizado    │
│ claro            │  │ convênios        │  │ clinicamente     │
│ {1_LINHA}        │  │ {1_LINHA}        │  │ {1_LINHA}        │
└──────────────────┘  └──────────────────┘  └──────────────────┘
```

**Regras:**
- Exatamente 6 cards (3x2 ou 2x3)
- Título de 2-3 palavras
- 1 linha de descrição
- Mesmos cards em todas as variações que usam esse estilo

---

## 3️⃣ Eixo 3 — Cor de destaque

| Variação | Cor | OKLCH | Hex | Quando funciona |
|---|---|---|---|---|
| v1 | 🟠 Laranja | `oklch(70% 0.20 50)` | `#FF6B00` | Universal · marketing · construção |
| v2 | 🔴 Vermelho | `oklch(60% 0.22 25)` | `#E53935` | Urgência · saúde · transformação |
| v3 | 🔵 Ciano | `oklch(70% 0.15 220)` | `#00B4D8` | Tech · finanças · tom calmo |
| v4 | 🟡 Amarelo | `oklch(80% 0.18 90)` | `#FFB300` | Otimismo · educação · criativo |
| v5 | 🟣 Roxo | `oklch(60% 0.20 290)` | `#7C3AED` | Premium · espiritualidade · diferenciado |

### Regras de uso da cor

- **Apenas 1 cor de destaque por variação** — nunca misture
- Aplica em: botão CTA · barra do topo · ícones · borders de cards · highlights da headline
- Fundo permanece **escuro** (`#0A0A0A` / `#141414`) em todas as variações
- Texto principal permanece **branco/cinza-claro**

### Como trocar a cor sem refazer

```tsx
// page.tsx da variação
<main style={{ "--accent": "oklch(70% 0.20 50)" } as React.CSSProperties}>
  {/* todos os componentes usam bg-accent / text-accent */}
</main>
```

---

## 4️⃣ Eixo 4 — CTA (texto e tom)

### v1 — Direto e funcional

```
QUERO ME INSCREVER POR {TICKET_INGRESSO}
```

**Tom:** transparente, foca no valor monetário.

### v2 — Foco no resultado

```
QUERO {RESULTADO_PRINCIPAL}
```

**Tom:** ambicioso, foca na transformação.

**Exemplos:** *"QUERO FATURAR R$ 100K"* · *"QUERO PERDER 7KG"*

### v3 — Escassez

```
GARANTIR MINHA VAGA AGORA
```

**Tom:** urgência, escassez implícita.

### v4 — Aspiracional

```
QUERO TER {TRANSFORMACAO}
```

**Tom:** projeção do futuro desejado.

**Exemplos:** *"QUERO TER A LIBERDADE FINANCEIRA"* · *"QUERO TER UMA AGENDA CHEIA"*

### v5 — Coloquial / próximo

```
BORA TRANSFORMAR ISSO
```

**Tom:** parceiro, time, intimidade.

---

## 🎲 Como rodar o teste das 5 variações

### Setup

1. **Sobe as 5 rotas no Cloudflare Pages** (já existem desde o setup inicial)
2. **Cria 5 campanhas de teste no Meta Ads**, uma pra cada variação:
   ```
   {SIGLA}_{DDMMYY}_TES-PAG_001  →  /v1
   {SIGLA}_{DDMMYY}_TES-PAG_002  →  /v2
   {SIGLA}_{DDMMYY}_TES-PAG_003  →  /v3
   {SIGLA}_{DDMMYY}_TES-PAG_004  →  /v4
   {SIGLA}_{DDMMYY}_TES-PAG_005  →  /v5
   ```
3. **Usa criativos JÁ VALIDADOS** (mesmos em todas as 5 campanhas — isolamento)
4. **R$ 50/dia mínimo por campanha** (regra LPSG · soma ≤ 20% do orçamento total)
5. **Roda 5-7 dias** pra dados estatísticos

### O que medir

| Métrica | Pra cada variação |
|---|---|
| **Conversão da página** (visitas → compras) | ≥ 5% mínimo |
| **Tempo médio na página** | ≥ 60s |
| **Scroll até "O que vai aprender"** | ≥ 50% |
| **Cliques no CTA primário (hero)** | ≥ 15% |
| **ROAS de ingresso** | ≥ 1.0 |

### Como decidir a vencedora

```
Variação vencedora = maior CONVERSÃO em 7 dias com ROAS ≥ alvo
```

- Diferença < 10% → estatisticamente igual · escolhe a mais simples de manter
- Diferença ≥ 10% → vencedora vira **principal**
- Vencedora vai pra `/`  (homepage redireciona pra ela)
- Outras 4 ficam ativas pra próxima rodada de teste

### Próxima rodada

- Mantém a vencedora intacta
- Cria 4 novas variações testando outros eixos (ou novas combinações)
- Repete o ciclo

---

## 📋 Tabela de preenchimento (use isso como briefing)

```
┌──────────┬───────────────┬─────────────────┬────────────┬──────────────┐
│ Variação │ Headline      │ Estrutura dor   │ Cor        │ CTA primário │
├──────────┼───────────────┼─────────────────┼────────────┼──────────────┤
│ v1       │ {HEADLINE_V1} │ Lista R$        │ Laranja    │ {CTA_V1}     │
│ v2       │ {HEADLINE_V2} │ Lista R$        │ Vermelho   │ {CTA_V2}     │
│ v3       │ {HEADLINE_V3} │ 6 cards         │ Ciano      │ {CTA_V3}     │
│ v4       │ {HEADLINE_V4} │ 6 cards         │ Amarelo    │ {CTA_V4}     │
│ v5       │ {HEADLINE_V5} │ Lista R$        │ Roxo       │ {CTA_V5}     │
└──────────┴───────────────┴─────────────────┴────────────┴──────────────┘
```

---

## 🚨 Erros comuns

| Erro | Por quê é ruim |
|---|---|
| Subir só 1 variação | Sem comparação · não aprende |
| Subir 10 variações de uma vez | Tráfego se dilui · sem dados estatísticos |
| Mudar 4 eixos de uma vez | Não dá pra isolar o que funcionou |
| Criativos diferentes em cada teste | Contamina dados · variável não isolada |
| Trocar cor sem testar | Cor afeta CR · não pula o teste |
| Manter perdedora "porque eu gostei" | Bias pessoal mata performance |
| Trocar variação principal toda semana | Sem maturidade nos dados |
# 05 · Performance & Deploy no Cloudflare Pages

> Página rápida vende mais. **LCP < 1.5s** é a regra do LPSG — não os 2s padrão da web. Mobile é tudo.

---

## 🎯 Por que performance é decisivo

| Métrica | Impacto direto |
|---|---|
| LCP +1s | -7% conversão (Akamai · Google) |
| Mobile com 3G | 40% dos brasileiros — não pode quebrar |
| CLS > 0.1 | Frustra clique no CTA · taxa de erro alta |
| INP > 200ms | "Página travou" · perde tráfego pro botão |

**Tradução:** se a página é lenta, **o tráfego pago vira prejuízo direto**. Você paga pelo clique e o lead nem vê o conteúdo.

---

## 📊 Métricas-alvo do LPSG

| Métrica | Mínimo | Ideal LPSG | Padrão Web |
|---|---|---|---|
| **LCP** (Largest Contentful Paint) | < 2.0s | **< 1.5s** | < 2.5s |
| **INP** (Interaction to Next Paint) | < 200ms | **< 100ms** | < 200ms |
| **CLS** (Cumulative Layout Shift) | < 0.1 | **< 0.05** | < 0.1 |
| **TTFB** (Time to First Byte) | < 600ms | **< 300ms** | < 800ms |
| **Lighthouse Mobile** | ≥ 90 | **≥ 95** | ≥ 75 |
| **Peso total da página** | < 2 MB | **< 1 MB** | — |
| **Peso da imagem do hero** | < 200 KB | **< 150 KB** | — |

---

## 🖼️ Otimização de imagens (a alavanca #1)

### Sempre `next/image`

```tsx
import Image from "next/image";

<Image
  src="/images/expert.webp"
  alt="{NOME_ESPECIALISTA}"
  width={600}
  height={600}
  priority           // SOMENTE no hero · resto: loading="lazy" implícito
  quality={85}       // 85 é o sweet spot
  placeholder="blur"
  blurDataURL="..."  // base64 LQIP
/>
```

### Formato e tamanho

| Tipo de imagem | Formato | Resolução máx | Peso máx |
|---|---|---|---|
| Hero (foto do expert) | AVIF + WebP | 800x800 | 150 KB |
| Depoimentos / fotos | WebP | 400x400 | 80 KB |
| Open Graph | JPG | 1200x630 | 200 KB |
| Ícones | SVG inline | — | < 5 KB |
| Logos | SVG | — | < 10 KB |

### Comando rápido pra otimizar

```bash
# Instala sharp e cwebp
brew install webp jpeg-turbo

# Converte JPG → WebP otimizado
cwebp -q 85 expert.jpg -o expert.webp

# Resize antes (se a original for grande)
magick expert-original.jpg -resize 800x800 -strip expert.jpg
```

### Lazy loading correto

| Onde | Estratégia |
|---|---|
| Hero | `priority` (carrega primeiro) |
| Acima da dobra | `priority` se visível |
| Abaixo da dobra | `loading="lazy"` (default no `next/image`) |
| Vídeos de depoimentos | `loading="lazy"` no iframe + `data-src` se complexo |

---

## 🎨 Fontes — não derrube o LCP

### Use `next/font` sempre

```tsx
import { Inter, Manrope } from "next/font/google";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",      // mostra fallback enquanto carrega
});
```

### Por que `next/font`?

- ✅ Self-hosted automático (sem chamada externa pro Google)
- ✅ Subset apenas o que usa
- ✅ `font-display: swap` automático
- ✅ Zero CLS por troca de fonte

### Pesos mínimos necessários

```tsx
const inter = Inter({
  weight: ["400", "600", "900"],   // só os que usa
  subsets: ["latin"],
});
```

---

## 🎬 Vídeos — manuseio cuidadoso

### Vídeos no hero — **NÃO usar**

Padrão LPSG: hero é **foto + texto**. Vídeo no topo derruba LCP.

### Vídeos de depoimentos

Embed lazy via `iframe` ou solução dedicada:

```tsx
// Versão simples
<iframe
  src={videoEmbed}
  loading="lazy"
  className="aspect-[9/16] w-full"
  allowFullScreen
/>

// Versão otimizada com placeholder
<div className="relative aspect-[9/16]">
  <Image src="/thumb.webp" fill alt="..." className="absolute" />
  <button onClick={() => loadVideo()}>▶ Assistir</button>
</div>
```

> **Dica:** placeholder que carrega o iframe **só após o clique** economiza ~200KB por vídeo no carregamento inicial.

---

## 🚀 Bundle size — mantenha enxuto

### Regras

- **Bundle JS inicial < 100 KB** (gzipped)
- **Bundle CSS < 30 KB** (gzipped)
- **Total < 1 MB** na primeira visita

### Como conferir

```bash
pnpm build
# Olha a coluna "First Load JS" no terminal
```

### O que evitar

| Biblioteca | Tamanho aproximado | Alternativa |
|---|---|---|
| Lodash completo | 70 KB | Funções nativas / lodash-es por função |
| Moment.js | 230 KB | `date-fns` (modular) ou `Intl.DateTimeFormat` nativo |
| jQuery | 30 KB | DOM API nativa |
| Material UI completo | 300+ KB | shadcn/ui (copia só o que precisa) |
| Tailwind UI sem purge | 3 MB | Configurar `content` corretamente no `tailwind.config` |

### Code splitting automático

Next.js já faz por rota. Cada `/v1`, `/v2`... carrega apenas o JS daquela página.

---

## 📡 Tracking e scripts externos

### Carregamento estratégico

```tsx
// src/app/layout.tsx
import Script from "next/script";

<Script
  id="meta-pixel"
  strategy="afterInteractive"     // depois do conteúdo principal
  dangerouslySetInnerHTML={{ __html: `...pixel code...` }}
/>

<Script
  id="gtm"
  strategy="afterInteractive"
  src="..."
/>
```

### Estratégias do `next/script`

| Strategy | Quando carrega | Quando usar |
|---|---|---|
| `beforeInteractive` | Antes do conteúdo | Crítico (auth, anti-fraud) — **raro** |
| `afterInteractive` | Após conteúdo | Pixel, GTM, GA · **padrão** |
| `lazyOnload` | Quando aba ociosa | Chats, widgets · não-críticos |

> **Padrão LPSG:** Pixel + GTM + GA = `afterInteractive`. Nunca `beforeInteractive`.

---

## 🌐 Cloudflare Pages — configurações de produção

### `next.config.ts`

```typescript
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "export",      // `npx next build` gera a pasta out/
  reactStrictMode: true,
  poweredByHeader: false,

  images: {
    unoptimized: true,   // export estático: imagens já sobem em WebP/AVIF otimizado
  },

  experimental: {
    optimizePackageImports: ["lucide-react"],  // tree-shaking automático
  },
};

export default nextConfig;
```

> Em export estático o Next **não** roda `redirects()` nem `headers()`. Os dois viram arquivos em `public/` (o build copia pra `out/`):

`public/_redirects`:

```
/  /v1  302
```

`public/_headers`:

```
/*
  X-Content-Type-Options: nosniff
  X-Frame-Options: DENY
  Referrer-Policy: strict-origin-when-cross-origin

/images/*
  Cache-Control: public, max-age=31536000, immutable
```

### Publicar

```bash
npx next build
npx wrangler pages deploy out --project-name {projeto} --branch main
```

Preview de uma variação antes de subir pra produção:

```bash
npx wrangler pages deploy out --project-name {projeto} --branch feature-x
# → https://feature-x.{projeto}.pages.dev
```

### Rede da Cloudflare

- **CDN global:** a pasta `out/` é servida pela rede da Cloudflare
- **HTTPS automático** no `{projeto}.pages.dev` e no domínio customizado

### Cloudflare Web Analytics (Core Web Vitals)

Liga em `Workers & Pages → projeto → Metrics → Enable (Web Analytics)`. Sem pacote, sem import, sem cookie.

Métricas reais (de usuários reais) aparecem no painel do Web Analytics:
- LCP, INP, CLS (Core Web Vitals)
- Page views por rota
- Mostra trend ao longo do tempo

---

## 🧪 Auditoria pré-deploy

### Lighthouse CLI (mobile)

```bash
pnpm dlx lighthouse https://lp.dominio.com.br/v1 \
  --preset=desktop \
  --form-factor=mobile \
  --output=html \
  --output-path=./reports/v1-mobile.html
```

Roda nas 5 variações antes de subir tráfego.

### PageSpeed Insights

```
https://pagespeed.web.dev/analysis?url=https://lp.dominio.com.br/v1
```

Ideal: **≥ 95 em mobile** (campo verde). Se < 90, **não suba tráfego ainda**.

### Critérios de aprovação por variação

- [ ] Lighthouse Mobile ≥ 95
- [ ] LCP < 1.5s (campo + lab)
- [ ] CLS < 0.05
- [ ] INP < 200ms (Real User Monitoring após 7 dias)
- [ ] Peso total < 1 MB
- [ ] Imagem do hero < 150 KB
- [ ] Sem warnings no console

---

## 🔒 Segurança e SEO básicos

### Headers de segurança (já no `public/_headers`)

- `X-Content-Type-Options: nosniff`
- `X-Frame-Options: DENY`
- `Referrer-Policy: strict-origin-when-cross-origin`

### Metadata (Open Graph + Twitter)

```tsx
// app/(variations)/v1/page.tsx
export const metadata = {
  title: "{HEADLINE_CURTA} | {NOME_EVENTO}",
  description: "{SUB_HEADLINE}",
  openGraph: {
    title: "{HEADLINE_CURTA}",
    description: "{SUB_HEADLINE}",
    images: ["/images/og-image.jpg"],
    locale: "pt_BR",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
  },
};
```

### `robots.txt`

```
# public/robots.txt
User-agent: *
Allow: /

Sitemap: https://lp.dominio.com.br/sitemap.xml
```

### Sitemap

`src/app/sitemap.ts`:

```typescript
export default function sitemap() {
  const base = "https://lp.dominio.com.br";
  return ["/v1", "/v2", "/v3", "/v4", "/v5"].map((url) => ({
    url: `${base}${url}`,
    lastModified: new Date(),
    changeFrequency: "weekly" as const,
    priority: 0.8,
  }));
}
```

---

## 📋 Checklist pré-deploy de cada variação

### Performance
- [ ] `pnpm build` sem warnings
- [ ] Lighthouse Mobile ≥ 95
- [ ] LCP < 1.5s
- [ ] CLS < 0.05
- [ ] INP < 200ms
- [ ] Peso total < 1 MB
- [ ] Imagem hero otimizada (WebP/AVIF · < 150 KB)

### Funcionamento
- [ ] Botão CTA leva pra checkout correto
- [ ] UTMs propagam pro checkout
- [ ] Pixel disparando `PageView` + `InitiateCheckout`
- [ ] GA4 recebendo eventos
- [ ] Página renderiza correta no iPhone SE (375px)
- [ ] Página renderiza correta no Galaxy A50 (412px)

### Conteúdo
- [ ] Foto do expert otimizada e rosto centralizado
- [ ] Data do evento na primeira dobra
- [ ] Garantia abaixo do botão (texto exato LPSG)
- [ ] Mínimo 6 depoimentos misturados
- [ ] CTA final repete garantia
- [ ] Footer com termos de uso e privacidade

### SEO + Sharing
- [ ] `<title>` único por variação
- [ ] `<meta description>` único por variação
- [ ] Open Graph image (1200x630)
- [ ] `robots.txt` permite indexação
- [ ] `sitemap.xml` lista as 5 variações

### Tracking
- [ ] Pixel ID correto
- [ ] CAPI configurado
- [ ] GTM ID correto
- [ ] GA4 ID correto
- [ ] Variáveis do projeto Pages populadas (`Settings → Variables and Secrets`)

### Pós-deploy
- [ ] URL de produção respondendo
- [ ] Domínio customizado HTTPS funcionando
- [ ] Cloudflare Web Analytics ativo e coletando LCP/INP/CLS
- [ ] Preview branch testado (`https://<branch>.{projeto}.pages.dev`)

---

## 🚨 Erros que matam performance

| Erro | Impacto |
|---|---|
| Imagem JPG não otimizada (>500 KB) | LCP +2s |
| `<img>` puro sem `next/image` | Sem AVIF/WebP · sem lazy nativo |
| Hero sem `priority` | LCP péssimo |
| Fonte Google Fonts via `<link>` direto | CLS por troca de fonte |
| Pixel/GTM com `beforeInteractive` | Atrasa LCP em 500ms+ |
| Bundle com Lodash completo | +70 KB sem necessidade |
| Vídeo no hero | Atrasa LCP em 1-3s |
| CSS-in-JS com runtime grande | Atraso no paint |
| Múltiplas requisições de fonte | Render-blocking |
| Reset CSS pesado | Bundle CSS inflado |

---

## 🔁 Rotina de manutenção

| Frequência | Ação |
|---|---|
| **Diário** | Conferir Cloudflare Web Analytics — visitas e Core Web Vitals por rota |
| **Semanal** | Lighthouse nas 5 variações · comparar com semana anterior |
| **A cada deploy** | Lighthouse + Web Analytics (Core Web Vitals) · não subir se piorou >5 pontos |
| **Mensal** | Auditoria de bundle size · remover dependências não usadas |
| **Trimestral** | Rever benchmarks · atualizar dependências (security patches) |

---
name: instalar-skill-no-squad
description: Instala uma Agent Skill de terceiros (GitHub / awesome-list) e a distribui nos agentes do Squad Turbo. Use quando o pedido for "instala essa skill", "instala esse repo de skill", "adiciona essa skill ao squad", "distribui a skill entre os agentes", "clona do GitHub pra ~/.claude/skills". Cobre: classificar a fonte, copiar a pasta self-contained pra ~/.claude/skills/, mapear a skill pro(s) agente(s) dono(s) em ~/.claude/agents/, e personalizar os triggers pro fluxo em português. NÃO é para criar skill do zero (isso é skill-creator), nem para publicar skill (skill-generalizer), nem para instalar plugin do Claude Code (/plugin) ou app npm.
---

# Instalar skill no Squad Turbo

Fluxo repetível para pegar uma skill de terceiros e deixá-la **ativa e amarrada ao agente certo** do Squad Turbo. Sempre em 5 passos.

## 0. Classificar a fonte primeiro (não pule)
Antes de instalar, olhe o README (WebFetch) e decida o que é — cada tipo tem caminho diferente:
- **Skill(s)** (tem `SKILL.md`) → siga esta skill.
- **Plugin do Claude Code** (marketplace / `/plugin install`) → é comando interativo no terminal `claude`; **não** dá pra instalar por Bash. Oriente o usuário.
- **App npm / repo executável** (`package.json`, `npm run …`) → clonar + `npm install` + rodar; não é skill.
- **Awesome-list** (README só com links) → não se instala; puxe o catálogo e ajude a escolher skills reais.

Se for skill, siga.

## 1. Instalar (clonar → localizar → copiar)
- Clone no scratchpad (não no projeto): `git clone --depth 1 <repo>`.
- Ache a pasta da skill: `find <repo> -iname SKILL.md`. Repos têm 3 formatos comuns:
  - `SKILL.md` na raiz → a raiz é a skill.
  - `skills/<nome>/SKILL.md` (monorepo) → copie só a subpasta que interessa.
  - várias subpastas com `SKILL.md` → é um pacote de skills; copie cada uma como pasta top-level.
- Confira conflito de nome em `~/.claude/skills/` antes de copiar.
- Copie a pasta **self-contained** (com SKILL.md + `references/`/`scripts/`) para `~/.claude/skills/<nome>/`. Não copie `.git`.
- Verifique: `[ -f ~/.claude/skills/<nome>/SKILL.md ] && echo OK`.

## 2. Distribuir — mapear skill → agente(s) dono(s)
Agentes ficam em `~/.claude/agents/<nome>.md`, cada um com um bloco `skills:` no frontmatter (grupos comentados). Adicione a skill ao(s) agente(s) certo(s) por natureza do trabalho:

| Natureza da skill | Agente(s) que recebe(m) |
| --- | --- |
| Copy / texto / anti-IA | `copywriter-turbo`, `revisor-copy-turbo` |
| Visual / página / design | `designer-turbo` (executa), `diretor-criativo-turbo` (dirige) |
| Pesquisa externa/mercado | `pesquisador-mercado-turbo` |
| Pesquisa interna / fundação | `pesquisador-turbo` |
| Conteúdo orgânico / vídeo / áudio | `social-turbo` |
| Tráfego / ads | `trafego-turbo` |
| Meta (criar/evoluir/publicar skills) | `estrategista-turbo` (orquestrador) |
| Utilitário genérico (ex.: file-organizer) | nenhum — fica global |

Edite o `skills:` de cada agente inserindo um grupo com comentário antes do `---` de fecho:
```yaml
  # <por que este agente usa esta skill>
  - <nome-da-skill>
```
Uma skill pode ir para mais de um agente. Não force utilitário genérico em agente nenhum.

## 3. Personalizar (triggers PT + defer)
Skills de terceiros vêm com trigger **só em inglês** e às vezes genérico demais — o squad fala **português**. Para cada skill instalada, edite a `description` do SKILL.md:
- **Adicione triggers em PT** com a fala real de quem usa o squad (ex.: "tirar a cara de IA", "gerar áudio", "transcrever vídeo").
- **Trave sobretrigger**: se o trigger for uma palavra ampla ("organizar", "gerar imagem"), restrinja e liste o que **NÃO** é (ex.: file-organizer = só arquivos no disco, não "organizar skills").
- **Nota de defer**: se pisar numa skill dedicada do squad, aponte a preferência (ex.: imagen → carrossel/story usa `gerador-instagram-turbo`).
- **Preserve** `name`, `license`, `author`, `version` — mexa só na `description`.

(Opcional: rode a skill `skill-personalizer` para um passe mais fundo.)

## 4. Verificar
- `grep -l "^  - <skill>$" ~/.claude/agents/*.md` → confirma em quais agentes entrou.
- Confirme que o YAML dos SKILL.md ainda parseia (o harness recarrega e mostra a description nova).
- Avise: as mudanças em skills e agentes valem na **próxima sessão** do Claude Code.

## Regras
- Terceiros = código não auditado: instale só de fontes confiáveis e o que você vai usar. Não execute scripts do repo às cegas.
- Instalação = colocar arquivos + amarrar no agente. Nunca insira credenciais/API keys; skills que precisam de chave pedem na 1ª execução.

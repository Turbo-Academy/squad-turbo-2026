# Sequências

Ordem canônica de blocos por perfil. Use como ponto de partida, corte o que não tem material, **nunca reordene por estética** — a ordem existe porque cada bloco derruba a objeção que o anterior levanta.

A coluna "forma" existe para você checar a regra da alternância: duas linhas seguidas nunca podem ter a mesma forma.

---

## Low ticket (R$ 17 – R$ 297)

Página curta. O leitor decide rápido, e cada seção a mais é uma chance de ele sair.

| # | Bloco | Forma | Derruba |
|---|---|---|---|
| 1 | `hero-oferta` | split-7-5 | "o que é isso e quanto custa" |
| 2 | `agitacao` | duas-colunas-opostas | "isso é problema meu mesmo?" |
| 3 | `split-argumento` + mock | split-imagem | "como funciona na prática" |
| 4 | `lista-densa` (o que está dentro) | lista-densa | "vale o que custa?" |
| 5 | Prova visual (depoimento em conversa) | mock-visual | "funciona pra gente como eu?" |
| 6 | `pra-quem` | duas-colunas-opostas | "é pra mim?" |
| 7 | `oferta-final` | faixa-escura | decisão |
| 8 | `garantia` | stack-vertical | "e se não gostar?" |
| 9 | `faq` (6–8) | acordeao | resíduo |

Mínimo viável: 1, 3, 4, 7, 9. Se o material for pouco, entregue 5 seções bem-feitas em vez de 9 vazias.

---

## Ingresso de evento / lançamento pago

Datas e formato precisam estar na primeira dobra. O leitor precisa saber se consegue estar presente antes de considerar o preço.

| # | Bloco | Forma | Derruba |
|---|---|---|---|
| 1 | `hero-evento` | stack + card | "quando, onde, quanto" |
| 2 | Cronograma resumido (3 cards de dia) | grid-cards | "o que acontece em cada dia" |
| 3 | `autoridade` (quem ensina, curto) | split-imagem | "quem é essa gente" |
| 4 | `split-argumento` (por que agora) | split-7-5 | "por que esse assunto, por que agora" |
| 5 | `timeline` (os dias em detalhe) | timeline | "o que exatamente eu vou aprender" |
| 6 | Entregáveis como peças (`prova-visual.md` §8) | grid-cards | "o que eu levo pra casa" |
| 7 | `pra-quem` | duas-colunas-opostas | "é pro meu nível?" |
| 8 | `transparencia` | stack-vertical | "vai ter pitch?" |
| 9 | `autoridade` (completo, um por professor) | split-imagem | autoridade profunda |
| 10 | `oferta-final` | faixa-escura | decisão |
| 11 | `faq` (8–10) | acordeao | resíduo |

Escassez: só use se for verdadeira e verificável (lote com data de virada, vagas com número real). Contador falso destrói mais do que a urgência constrói — e a `criador-paginas-low-ticket-turbo` vai flagrar isso na auditoria.

---

## Captura de lead / lançamento gratuito

Não vende nada. O objetivo é o formulário. Página **curta** — mais seção é mais chance de perder o lead.

| # | Bloco | Forma | Derruba |
|---|---|---|---|
| 1 | `hero-evento` com formulário no lugar do preço | split-7-5 | "o que eu ganho e o que eu dou" |
| 2 | `lista-densa` (o que você vai ver) | lista-densa | "vale meu email?" |
| 3 | `autoridade` (curto) | split-imagem | "quem é" |
| 4 | Prova visual (uma só) | mock-visual | credibilidade |
| 5 | CTA repetido | faixa-escura | decisão |
| 6 | `faq` (4–5) | acordeao | resíduo |

Máximo 6 seções. O formulário pede **o mínimo**: nome + WhatsApp, ou só email. Cada campo extra derruba conversão.

---

## High ticket (aplicação / call)

Ninguém compra R$ 5k+ numa página. A página qualifica e agenda. Densidade e sobriedade > entusiasmo.

| # | Bloco | Forma | Derruba |
|---|---|---|---|
| 1 | `hero-editorial` | stack + full-bleed | "isso é sério?" |
| 2 | `agitacao` (específica do nível dele) | duas-colunas-opostas | "esse cara entende meu problema" |
| 3 | `split-argumento` (o método) | split-7-5 | "qual é o mecanismo" |
| 4 | Tabela comparativa | tabela | "por que não a alternativa" |
| 5 | `autoridade` (longo, editorial) | split-imagem | "por que ele" |
| 6 | Prova visual (caso real, com número) | mock-visual | "funciona" |
| 7 | `pra-quem` (filtro duro) | duas-colunas-opostas | qualificação |
| 8 | `modulos` ou o que acontece no processo | grid-cards | "como é a entrega" |
| 9 | CTA de aplicação + o que acontece depois | faixa-escura | "o que acontece se eu clicar" |
| 10 | `faq` (6–8, focado em processo e investimento) | acordeao | resíduo |

Preço: se não está na página, o bloco 9 tem que dizer a faixa ou dizer explicitamente que o valor é apresentado na call. Silêncio total sobre preço aumenta o show rate ruim.

---

## Upsell / order bump (pós-compra)

Página muito curta. O leitor já comprou, já confia. Uma dobra e meia.

| # | Bloco | Forma |
|---|---|---|
| 1 | Hero com contexto do que ele acabou de comprar | stack |
| 2 | O que o complemento resolve (3 pontos) | lista-densa |
| 3 | Oferta + os dois botões (aceitar / recusar) | faixa-escura |

O botão de recusar precisa existir e ser legível. Esconder o "não" gera reembolso e chargeback.

---

## Checagem final da sequência

Antes de gerar, liste as seções com a forma de cada uma e confira:

- [ ] Nenhuma forma repetida em linhas consecutivas
- [ ] Pelo menos 7 formas diferentes numa página de 10+ seções
- [ ] Exatamente **uma** `faixa-escura` (duas competem entre si)
- [ ] Pelo menos dois `mock-visual`
- [ ] CTA aparece no mínimo 3 vezes: hero, meio, oferta final
- [ ] Todos os CTAs apontam para o mesmo destino e dizem a mesma coisa

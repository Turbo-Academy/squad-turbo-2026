# SEO — portão antes de publicar qualquer página

Referência de partida: checklist "20 ajustes pro Google achar o seu site feito com IA" (fabiano.app).
Este arquivo é a versão do Squad Turbo: cada item diz **o que fazer** e **como conferir de fora** — conferir é o que
separa "fiz" de "está feito".

**Regra de ordem:** os blocos vão na ordem. O Bloco 1 é pré-requisito — sem ele, nada do resto é lido por ninguém.
Tentar os vinte de uma vez é o jeito mais rápido de não fazer nenhum.

---

## BLOCO 1 — Deixar entrar (binário: ou o buscador entra, ou não entra)

| # | O que | Como conferir de fora |
|---|---|---|
| 3 | **Nenhuma marcação que bloqueia indexação.** Gerador de site costuma deixar `noindex` ligado por padrão — o site inteiro fica invisível por uma linha. Procurar no `<meta name="robots">` **e** no cabeçalho HTTP `X-Robots-Tag`. | `curl -sI URL \| grep -i x-robots` e `curl -s URL \| grep -i 'name="robots"'` → nenhum `noindex` |
| 1 | **`sitemap.xml`** existe e lista as páginas **reais** (não as de teste, não 404). | `curl -s DOMINIO/sitemap.xml` → HTTP 200, e cada `<loc>` responde 200 |
| 2 | **`robots.txt`** não bloqueia tudo por engano e aponta o sitemap. | `curl -s DOMINIO/robots.txt` → sem `Disallow: /` solto; tem `Sitemap: …` |
| 16 | **HTTPS forçado**, com redirecionamento do HTTP. | `curl -sI http://DOMINIO` → 301/308 para `https://` |

## BLOCO 2 — Deixar entender (aqui o buscador decide do que a página trata)

| # | O que | Como conferir de fora |
|---|---|---|
| 5 | **`<title>` único por página**, escrito pra pessoa, não pra robô. | títulos diferentes entre as páginas do sitemap |
| 6 | **`<meta name="description">` única por página**, que descreve de verdade. | presente e diferente em cada página |
| 7 | **Um `<h1>` só por página**, e ele diz o que a página é. | contagem de `<h1>` = 1 |
| 8 | **Hierarquia de cabeçalhos** sem pular nível (h1 → h2 → h3). | nenhum `h3` sem `h2` antes |
| 4 | **Tag canônica** apontando pra versão oficial da página. | `<link rel="canonical" href="https://…">` presente e absoluto |
| 17 | **Endereços limpos**: slug curto, minúsculo, com hífen, sem parâmetro inútil. | inspeção dos `<loc>` do sitemap |
| 11 | **Links internos** ligando as páginas entre si. | cada página tem ao menos um link pra outra do domínio |
| 10 | **Dados estruturados** (JSON-LD) dizendo se é produto, artigo, curso, serviço, organização. **Sem `offers`/preço** (é uma 2ª cópia do preço, que diverge em silêncio no Google); preço só com decisão explícita do dono + verificador bloco×página. | `<script type="application/ld+json">` válido **na página publicada**: `curl -s -X POST https://validator.schema.org/validate --data-urlencode "url=<URL>" \| tail -c +5` → `fetchError` null, `totalNumErrors` 0 (Rich Results Test do Google só no navegador) |
| 12 | **Nenhum link quebrado.** | todos os `href` internos respondem 200 |

## BLOCO 3 — Deixar rápido e apresentável

| # | O que | Como conferir de fora |
|---|---|---|
| 18 | **Imagem de compartilhamento** (`og:image`, `og:title`, `og:description`, `twitter:card`). É o item de **melhor retorno por esforço** da lista e o mais esquecido: é a diferença entre o link parecer profissional ou quebrado quando alguém cola no WhatsApp. | as tags existem; a `og:image` é URL absoluta e responde 200; ~1200×630 |
| 13 | **Imagens comprimidas** (WebP/AVIF, tamanho certo, `loading="lazy"` abaixo da dobra). | nenhuma imagem acima de ~300 KB sem motivo |
| 9 | **Texto alternativo** (`alt`) em toda imagem que carrega significado. | nenhuma `<img>` de conteúdo sem `alt` |
| 14 | **Core Web Vitals** (LCP, INP, CLS) no verde. | PageSpeed Insights / Lighthouse, **no celular** |
| 15 | **Responsivo no celular**, testado em rede lenta. | viewport presente; testar em 360px de largura |

## CAMADA NOVA — Aparecer nas respostas de IA

Muita gente hoje pergunta pra uma IA antes de pesquisar. Muito template **bloqueia por padrão** os rastreadores dos
modelos (`GPTBot`, `ClaudeBot`, `Google-Extended`, `PerplexityBot`, `CCBot`…) numa decisão que fazia sentido em outro
contexto. Quem vende pra esse público some de um canal inteiro sem perceber.

- Abrir o `robots.txt` e ler as regras de `User-agent`.
- **Decidir conscientemente**: liberar ou bloquear — mas sabendo. A decisão de negócio é do dono do site; o que não pode é
  estar bloqueado por acidente.
- Texto claro e estruturado ajuda buscador e modelo ao mesmo tempo.

## FORA DO SITE (não se resolve no código)

| # | O que |
|---|---|
| 19 | **Search Console**: crie (uma vez) a propriedade de domínio do seu site. Depois de publicar, conferir lá se o buscador **passou a entrar** — é a prova do Bloco 1. |
| 20 | **Estratégia de backlinks**: outros sites apontando pro nosso. É trabalho contínuo, não item de código. |
| — | **Negócio local**: o perfil do Google Empresas preenchido costuma trazer mais cliente que o site inteiro. Vem antes dos vinte. |

---

## AS SEIS CONFERÊNCIAS OBJETIVAS — sem elas, a página não está pronta

1. Nenhuma página tem `noindex` por engano.
2. O `sitemap.xml` existe e lista as páginas certas.
3. Cada página tem **um** `<h1>`, que diz o que ela é.
4. O link colado no WhatsApp mostra **imagem e título corretos**.
5. O site abre rápido no celular, testado em rede lenta.
6. A decisão sobre os rastreadores de IA foi **consciente**.

**Teste de 30 segundos antes de tudo:** pesquisar `site:DOMINIO` no Google. Se aparecer pouca coisa ou nada, o
problema é o Bloco 1 — e nenhum conteúdo novo resolve.

## COMO TRABALHAR NISSO (o fluxo que produz correção, não lista genérica)

1. **Com o código na mão, não só a URL.** Sem o código, sai conselho de manual.
2. **Um bloco por vez.** Bloco 1 inteiro, aplica, confere. Só então o 2.
3. **Todo achado com arquivo e linha.** Sem isso não dá pra conferir.
4. **Texto pronto pra colar**: title, description e JSON-LD saem escritos, não como instrução.
5. **Confirmar depois, de fora**: `curl` nas conferências acima e o Search Console.
